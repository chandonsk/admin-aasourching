from django.db import models
from .common import Users

class GuestManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(user_type=9)

class Guest(Users):
    objects = GuestManager()
    class Meta:
        proxy = True
        verbose_name = 'Guest'
        verbose_name_plural = 'Guests'
