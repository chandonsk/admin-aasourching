from django.db import models

class StaffRole(models.Model):
    name = models.CharField(max_length=50, unique=True)
    permissions = models.TextField(null=True, blank=True)  # Comma-separated or JSON for permissions
    date_created = models.DateTimeField(auto_now_add=True)
    date_modified = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.name

class StaffShift(models.Model):
    name = models.CharField(max_length=100, unique=True)
    time_start = models.TimeField()
    time_end = models.TimeField()
    date_created = models.DateTimeField(auto_now_add=True)
    date_modified = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name
