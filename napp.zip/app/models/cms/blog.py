from django.db import models

class BlogCategory(models.Model):
    STATUS_CHOICES = (
        ('1', 'Active'),
        ('0', 'Inactive'),
    )
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=1, choices=STATUS_CHOICES, default='1')

    def __str__(self):
        return self.name

class Blog(models.Model):
    STATUS_CHOICES = (
        ('1', 'Published'),
        ('2', 'Draft'),
        ('3', 'Archived'),
    )
    title = models.CharField(max_length=255)
    category = models.ForeignKey(BlogCategory, on_delete=models.CASCADE, related_name='blogs')
    image = models.ImageField(upload_to='blog_images/%Y/%m/', null=True, blank=True)
    content = models.TextField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='2')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
