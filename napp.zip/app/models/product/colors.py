from django.db import models

class ProductColor(models.Model):
    STATUS_CHOICES = (
        ('1', 'Active'),
        ('0', 'Inactive'),
    )
    name = models.CharField(max_length=50, unique=True)
    value = models.CharField(max_length=7)  # HEX color code, e.g. #FFFFFF
    status = models.CharField(max_length=1, choices=STATUS_CHOICES, default='1')

    def __str__(self):
        return f"{self.name} ({self.value})"
