from django.db import models

class Product(models.Model):
    GENDER_CHOICES = (
        (1, 'Men'),
        (2, 'Women'),
        (3, 'Unisex'),
        (4, 'Children'),
    )
    id = models.BigAutoField(primary_key=True)
    productline_id = models.IntegerField()
    category_id = models.IntegerField()
    sustainability_id = models.IntegerField(null=True, blank=True)
    colors_id = models.IntegerField(null=True, blank=True)
    min_size_id = models.IntegerField(null=True, blank=True)
    max_size_id = models.IntegerField(null=True, blank=True)
    fit_id = models.IntegerField(null=True, blank=True)
    gender = models.IntegerField(choices=GENDER_CHOICES, default=1)

    product_code = models.CharField(max_length=100)
    product_name = models.CharField(max_length=255)
    is_highlighted = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_featured = models.BooleanField(default=False)
    specifications = models.TextField(null=True, blank=True)
    gsm = models.CharField(max_length=50, null=True, blank=True)
    product_image = models.CharField(max_length=255, null=True, blank=True)
    product_images = models.JSONField(null=True, blank=True)

    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.product_name

class ProductDetails(models.Model):
    id = models.BigAutoField(primary_key=True)
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='additional_details')
    product_details = models.TextField(null=True, blank=True)
    printing_options = models.TextField(null=True, blank=True)
    textile_care = models.TextField(null=True, blank=True)
    packaging = models.CharField(max_length=255, null=True, blank=True)
    counterparts = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return f"Additional Details for {self.product.product_name}"

class ProductMeta(models.Model):
    id = models.BigAutoField(primary_key=True)
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='meta')
    meta_title = models.TextField(null=True, blank=True)
    meta_description = models.TextField(null=True, blank=True)
    meta_keywords = models.TextField(null=True, blank=True)
    meta_robots = models.TextField(null=True, blank=True)
    meta_canonical = models.TextField(null=True, blank=True)
    meta_social = models.JSONField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Meta for {self.product.product_name}"
