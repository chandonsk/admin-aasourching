from django.db import models
from .lines import ProductLine

class ProductCategory(models.Model):
    STATUS_CHOICES = (
        ('1', 'Active'),
        ('0', 'Inactive'),
    )
    product_line = models.ForeignKey(ProductLine, on_delete=models.CASCADE, related_name='categories')
    name = models.CharField(max_length=100)  # removed unique=True
    description = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='1')

    class Meta:
        unique_together = ('product_line', 'name')

    def __str__(self):
        return self.name
