from django.db import models

class BrandClient(models.Model):
    STATUS_CHOICES = (
        ('1', 'Active'),
        ('0', 'Inactive'),
        ('-1', 'Deleted'),
    )
    name = models.CharField(max_length=255)
    website = models.URLField(blank=True, null=True)
    email = models.EmailField(max_length=255)
    phone = models.CharField(max_length=30)
    avatar = models.ImageField(upload_to='brandclient_avatars/%Y/%m/', null=True, blank=True)
    status = models.CharField(max_length=2, choices=STATUS_CHOICES, default='1')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
