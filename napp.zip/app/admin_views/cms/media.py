from django.shortcuts import render

def media_all(request):
    return render(request, 'mainadmin/cms/media/all.html')

def media_add(request):
    return render(request, 'mainadmin/cms/media/add.html')

def media_category(request):
    return render(request, 'mainadmin/cms/media/category.html')
