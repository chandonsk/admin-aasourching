from django.http import HttpResponse

def account_profile(request):
    return HttpResponse('My Account Profile')
def account_balance(request):
    return HttpResponse('My Account Balance')
def account_settings(request):
    return HttpResponse('My Account Settings')
def account_security(request):
    return HttpResponse('My Account Security')
def account_notifications(request):
    return HttpResponse('My Account Notifications')

__all__ = [
    'account_profile', 'account_balance', 'account_settings', 'account_security', 'account_notifications'
]
