from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from app.models.product.brand import ProductBrand
from app.models.product.categories import ProductCategory
from app.models.product.lines import ProductLine
from app.models.product.colors import ProductColor
from app.models.product.sustainability import ProductSustainability
from app.models.product.fit import ProductFit
from app.models.product.size_range import ProductSizeRange
from app.models.product.attributes import ProductAttribute
# ...import ProductReview, Products if needed...

def paginate_queryset(qs, page, page_size):
    total = qs.count()
    start = (page - 1) * page_size
    end = start + page_size
    results = list(qs[start:end])
    return results, total

def serialize_brand(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "desc": obj.description,
        "status": "Active" if getattr(obj, "is_active", True) else "Inactive"
    }

def serialize_category(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "desc": obj.description,
        "status": "Active" if obj.status == "1" else "Inactive"
    }

def serialize_line(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "desc": obj.description,
        "status": "Active" if obj.status == "1" else "Inactive"
    }

def serialize_color(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "value": obj.value,
        "status": "Active" if obj.status == "1" else "Inactive"
    }

def serialize_sustainability(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "desc": obj.description,
        "status": "Active" if obj.status == "1" else "Inactive"
    }

def serialize_fit(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "desc": obj.description,
        "status": "Active" if obj.status == "1" else "Inactive"
    }

def serialize_size_range(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "desc": obj.description,
        "status": "Active" if obj.status == "1" else "Inactive"
    }

def serialize_attribute(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "desc": obj.description,
        "status": "Active" if obj.status == "1" else "Inactive"
    }

# BRAND
@csrf_exempt
def products_brand_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    qs = ProductBrand.objects.all().order_by('-id')
    results, total = paginate_queryset(qs, page, page_size)
    data = [serialize_brand(obj) for obj in results]
    return JsonResponse({
        "results": data,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size
    })

@csrf_exempt
def products_brand_pagination(request):
    return products_brand_get(request)

@csrf_exempt
def products_brand_add(request):
    # Add logic to save new brand
    return JsonResponse({"status": "success", "message": "Brand added."})

# CATEGORY
@csrf_exempt
def products_category_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    qs = ProductCategory.objects.all().order_by('-id')
    results, total = paginate_queryset(qs, page, page_size)
    data = [serialize_category(obj) for obj in results]
    return JsonResponse({
        "results": data,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size
    })

@csrf_exempt
def products_category_pagination(request):
    return products_category_get(request)

@csrf_exempt
def products_category_add(request):
    # Add logic to save new category
    return JsonResponse({"status": "success", "message": "Category added."})

# LINE
@csrf_exempt
def products_line_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    qs = ProductLine.objects.all().order_by('-id')
    results, total = paginate_queryset(qs, page, page_size)
    data = [serialize_line(obj) for obj in results]
    return JsonResponse({
        "results": data,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size
    })

@csrf_exempt
def products_line_pagination(request):
    return products_line_get(request)

@csrf_exempt
def products_line_add(request):
    return JsonResponse({"status": "success", "message": "Line added."})

# COLORS
@csrf_exempt
def products_colors_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    qs = ProductColor.objects.all().order_by('-id')
    results, total = paginate_queryset(qs, page, page_size)
    data = [serialize_color(obj) for obj in results]
    return JsonResponse({
        "results": data,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size
    })

@csrf_exempt
def products_colors_pagination(request):
    return products_colors_get(request)

@csrf_exempt
def products_colors_add(request):
    return JsonResponse({"status": "success", "message": "Color added."})

# SUSTAINABILITY
@csrf_exempt
def products_sustainability_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    qs = ProductSustainability.objects.all().order_by('-id')
    results, total = paginate_queryset(qs, page, page_size)
    data = [serialize_sustainability(obj) for obj in results]
    return JsonResponse({
        "results": data,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size
    })

@csrf_exempt
def products_sustainability_pagination(request):
    return products_sustainability_get(request)

@csrf_exempt
def products_sustainability_add(request):
    return JsonResponse({"status": "success", "message": "Sustainability type added."})

# FIT
@csrf_exempt
def products_fit_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    qs = ProductFit.objects.all().order_by('-id')
    results, total = paginate_queryset(qs, page, page_size)
    data = [serialize_fit(obj) for obj in results]
    return JsonResponse({
        "results": data,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size
    })

@csrf_exempt
def products_fit_pagination(request):
    return products_fit_get(request)

@csrf_exempt
def products_fit_add(request):
    return JsonResponse({"status": "success", "message": "Fit added."})

# SIZE RANGE
@csrf_exempt
def products_size_range_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    qs = ProductSizeRange.objects.all().order_by('-id')
    results, total = paginate_queryset(qs, page, page_size)
    data = [serialize_size_range(obj) for obj in results]
    return JsonResponse({
        "results": data,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size
    })

@csrf_exempt
def products_size_range_pagination(request):
    return products_size_range_get(request)

@csrf_exempt
def products_size_range_add(request):
    return JsonResponse({"status": "success", "message": "Size range added."})

# ATTRIBUTES
@csrf_exempt
def products_attributes_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    qs = ProductAttribute.objects.all().order_by('-id')
    results, total = paginate_queryset(qs, page, page_size)
    data = [serialize_attribute(obj) for obj in results]
    return JsonResponse({
        "results": data,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size
    })

@csrf_exempt
def products_attributes_pagination(request):
    return products_attributes_get(request)

@csrf_exempt
def products_attributes_add(request):
    return JsonResponse({"status": "success", "message": "Attribute added."})

# REVIEWS
@csrf_exempt
def products_reviews_get(request):
    # ...implement if you have ProductReview model...
    return JsonResponse({"results": [], "total": 0, "page": 1, "page_size": 10, "total_pages": 0})

@csrf_exempt
def products_reviews_pagination(request):
    return products_reviews_get(request)

@csrf_exempt
def products_reviews_add(request):
    return JsonResponse({"status": "success", "message": "Review added."})

# ALL PRODUCTS
@csrf_exempt
def products_all_get(request):
    # ...implement if you have Products model...
    return JsonResponse({"results": [], "total": 0, "page": 1, "page_size": 10, "total_pages": 0})

@csrf_exempt
def products_all_pagination(request):
    return products_all_get(request)

@csrf_exempt
def products_all_add(request):
    # ...existing code...
    return JsonResponse({"status": "success", "message": "Product added."})
