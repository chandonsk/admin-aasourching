from django.shortcuts import render

def notifications_all(request):
    return render(request, 'mainadmin/notifications/all.html')
def notifications_logs(request):
    return render(request, 'mainadmin/notifications/logs.html')

__all__ = ['notifications_all', 'notifications_logs']
