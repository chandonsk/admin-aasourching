from django.shortcuts import render

def marketing_coupons(request):
    return render(request, 'mainadmin/marketing/coupons.html')
def marketing_campaigns(request):
    return render(request, 'mainadmin/marketing/campaigns.html')
def marketing_banners(request):
    return render(request, 'mainadmin/marketing/banners.html')
def marketing_newsletters(request):
    return render(request, 'mainadmin/marketing/newsletters.html')

__all__ = ['marketing_coupons', 'marketing_campaigns', 'marketing_banners', 'marketing_newsletters']
