# transactions_api.py

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def transactions_get(request):
    return JsonResponse({"status": "success", "message": "transactions_get placeholder"})

@csrf_exempt
def transactions_pagination(request):
    return JsonResponse({"status": "success", "message": "transactions_pagination placeholder"})

@csrf_exempt
def transactions_add(request):
    return JsonResponse({"status": "success", "message": "transactions_add placeholder"})

@csrf_exempt
def transactions_incomming_get(request):
    return JsonResponse({"status": "success", "message": "transactions_incomming_get placeholder"})

@csrf_exempt
def transactions_incomming_pagination(request):
    return JsonResponse({"status": "success", "message": "transactions_incomming_pagination placeholder"})

@csrf_exempt
def transactions_incomming_add(request):
    return JsonResponse({"status": "success", "message": "transactions_incomming_add placeholder"})

@csrf_exempt
def transactions_outgoging_get(request):
    return JsonResponse({"status": "success", "message": "transactions_outgoging_get placeholder"})

@csrf_exempt
def transactions_outgoging_pagination(request):
    return JsonResponse({"status": "success", "message": "transactions_outgoging_pagination placeholder"})

@csrf_exempt
def transactions_outgoging_add(request):
    return JsonResponse({"status": "success", "message": "transactions_outgoging_add placeholder"})

@csrf_exempt
def transactions_edit(request):
    return JsonResponse({"status": "success", "message": "transactions_edit placeholder"})

@csrf_exempt
def transactions_delete(request):
    return JsonResponse({"status": "success", "message": "transactions_delete placeholder"})

@csrf_exempt
def transactions_incomming_edit(request):
    return JsonResponse({"status": "success", "message": "transactions_incomming_edit placeholder"})

@csrf_exempt
def transactions_incomming_delete(request):
    return JsonResponse({"status": "success", "message": "transactions_incomming_delete placeholder"})

@csrf_exempt
def transactions_outgoging_edit(request):
    return JsonResponse({"status": "success", "message": "transactions_outgoging_edit placeholder"})

@csrf_exempt
def transactions_outgoging_delete(request):
    return JsonResponse({"status": "success", "message": "transactions_outgoging_delete placeholder"})
