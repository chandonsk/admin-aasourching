from django.http import JsonResponse

def mainadmin(request):
    return JsonResponse({"status": "success", "message": "mainadmin API root"})
