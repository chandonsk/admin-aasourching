# message_api.py

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def message_get(request):
    return JsonResponse({"status": "success", "message": "message_get placeholder"})

@csrf_exempt
def message_pagination(request):
    return JsonResponse({"status": "success", "message": "message_pagination placeholder"})

@csrf_exempt
def message_add(request):
    return JsonResponse({"status": "success", "message": "message_add placeholder"})

@csrf_exempt
def message_edit(request):
    return JsonResponse({"status": "success", "message": "message_edit placeholder"})

@csrf_exempt
def message_delete(request):
    return JsonResponse({"status": "success", "message": "message_delete placeholder"})
