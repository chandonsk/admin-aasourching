# __init__.py

# Make sure this import matches your actual mainadmin.py file and function
from app.admin_views.api.mainadmin import mainadmin