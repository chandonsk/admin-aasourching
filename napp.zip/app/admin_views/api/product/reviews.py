from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def products_reviews_get(request):
    return JsonResponse({"status": "success", "message": "products_reviews_get placeholder"})

@csrf_exempt
def products_reviews_pagination(request):
    return JsonResponse({"status": "success", "message": "products_reviews_pagination placeholder"})

@csrf_exempt
def products_reviews_add(request):
    return JsonResponse({"status": "success", "message": "products_reviews_add placeholder"})


@csrf_exempt
def products_reviews_edit(request):
    return JsonResponse({"status": "success", "message": "products_reviews_edit placeholder"})

@csrf_exempt
def products_reviews_delete(request):
    return JsonResponse({"status": "success", "message": "products_reviews_delete placeholder"})