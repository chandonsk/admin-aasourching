from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from app.models.product.colors import ProductColor
import json

def serialize_color(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "value": obj.value,
        "status": "Active" if obj.status == "1" else "Inactive"
    }

def paginate_queryset(qs, page, page_size):
    total = qs.count()
    start = (page - 1) * page_size
    end = start + page_size
    results = list(qs[start:end])
    return results, total

@csrf_exempt
def products_colors_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    qs = ProductColor.objects.all().order_by('-id')
    results, total = paginate_queryset(qs, page, page_size)
    data = [serialize_color(obj) for obj in results]
    return JsonResponse({
        "results": data,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size
    })

@csrf_exempt
def products_colors_pagination(request):
    return products_colors_get(request)

@csrf_exempt
def products_colors_add(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            name = data.get("name", "").strip()
            value = data.get("value", "").strip()
            if not name or not value:
                return JsonResponse({"status": "error", "message": "Name and color value are required."}, status=400)
            # Check for duplicate color name
            if ProductColor.objects.filter(name=name).exists():
                return JsonResponse({"status": "error", "message": "Color name already exists."}, status=400)
            color = ProductColor.objects.create(name=name, value=value, status="1")
            return JsonResponse({"status": "success", "message": "Color added.", "id": color.id})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
    return JsonResponse({"status": "error", "message": "Invalid request method."}, status=405)

@csrf_exempt
def products_colors_edit(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            color_id = data.get("id")
            name = data.get("name", "").strip()
            value = data.get("value", "").strip()
            if not color_id or not name or not value:
                return JsonResponse({"status": "error", "message": "ID, name, and value are required."}, status=400)
            try:
                color = ProductColor.objects.get(id=color_id)
            except ProductColor.DoesNotExist:
                return JsonResponse({"status": "error", "message": "Color not found."}, status=404)
            # Check for duplicate name (excluding self)
            if ProductColor.objects.filter(name=name).exclude(id=color_id).exists():
                return JsonResponse({"status": "error", "message": "Color name already exists."}, status=400)
            color.name = name
            color.value = value
            color.save()
            return JsonResponse({"status": "success", "message": "Color updated."})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
    return JsonResponse({"status": "error", "message": "Invalid request method."}, status=405)

@csrf_exempt
def products_colors_delete(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            color_id = data.get("id")
            if not color_id:
                return JsonResponse({"status": "error", "message": "ID is required."}, status=400)
            try:
                color = ProductColor.objects.get(id=color_id)
            except ProductColor.DoesNotExist:
                return JsonResponse({"status": "error", "message": "Color not found."}, status=404)
            color.delete()
            return JsonResponse({"status": "success", "message": "Color deleted."})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
    return JsonResponse({"status": "error", "message": "Invalid request method."}, status=405)
