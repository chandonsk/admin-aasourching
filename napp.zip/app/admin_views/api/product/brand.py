from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from app.models.product.brand import ProductBrand

def serialize_brand(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "desc": obj.description,
        "status": "Active" if getattr(obj, "is_active", True) else "Inactive"
    }

def paginate_queryset(qs, page, page_size):
    total = qs.count()
    start = (page - 1) * page_size
    end = start + page_size
    results = list(qs[start:end])
    return results, total

@csrf_exempt
def products_brand_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    qs = ProductBrand.objects.all().order_by('-id')
    results, total = paginate_queryset(qs, page, page_size)
    data = [serialize_brand(obj) for obj in results]
    return JsonResponse({
        "results": data,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size
    })

@csrf_exempt
def products_brand_pagination(request):
    return products_brand_get(request)

@csrf_exempt
def products_brand_add(request):
    if request.method == "POST":
        import json
        try:
            data = json.loads(request.body.decode())
            name = data.get("name", "").strip()
            desc = data.get("desc", "").strip()
            if not name:
                return JsonResponse({"status": "error", "message": "Brand name is required."}, status=400)
            brand = ProductBrand.objects.create(name=name, description=desc)
            return JsonResponse({"status": "success", "message": "Brand added.", "id": brand.id})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
    return JsonResponse({"status": "error", "message": "Invalid request method."}, status=405)

@csrf_exempt
def products_brand_edit(request):
    if request.method == "POST":
        import json
        try:
            data = json.loads(request.body.decode())
            brand_id = data.get("id")
            name = data.get("name", "").strip()
            desc = data.get("desc", "").strip()
            if not brand_id or not name:
                return JsonResponse({"status": "error", "message": "ID and name are required."}, status=400)
            try:
                brand = ProductBrand.objects.get(id=brand_id)
            except ProductBrand.DoesNotExist:
                return JsonResponse({"status": "error", "message": "Brand not found."}, status=404)
            brand.name = name
            brand.description = desc
            brand.save()
            return JsonResponse({"status": "success", "message": "Brand updated."})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
    return JsonResponse({"status": "error", "message": "Invalid request method."}, status=405)

@csrf_exempt
def products_brand_delete(request):
    if request.method == "POST":
        import json
        try:
            data = json.loads(request.body.decode())
            brand_id = data.get("id")
            if not brand_id:
                return JsonResponse({"status": "error", "message": "ID is required."}, status=400)
            try:
                brand = ProductBrand.objects.get(id=brand_id)
            except ProductBrand.DoesNotExist:
                return JsonResponse({"status": "error", "message": "Brand not found."}, status=404)
            brand.delete()
            return JsonResponse({"status": "success", "message": "Brand deleted."})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
    return JsonResponse({"status": "error", "message": "Invalid request method."}, status=405)
