# views.py

from django.shortcuts import render, redirect
from app.models.user.common import Users
from django.http import JsonResponse, HttpResponse
from app.models.country import Country
from django.views.decorators.csrf import csrf_exempt
import json

def mainadmin_index(request):
    user_id = request.session.get('user_id')
    user_type = request.session.get('user_type')
    if not user_id or user_type != 1:
        return redirect('/signin/')
    #user = Users.objects.get(id=user_id)
    # Only redirect to notverified if BOTH are False (0)
    #if not (user.is_email_verified or user.is_phone_verified):
    #    return redirect('/myadmin/notverified')
    return render(request, 'mainadmin/index.html')#, {'user': user})

def forms(request):
    user_id = request.session.get('user_id')
    user_type = request.session.get('user_type')
    if not user_id or user_type != 1:
        return redirect('/signin/')
    user = Users.objects.get(id=user_id)

    return render(request, 'mainadmin/forms/forms.html', {'user': user})

def order_view(request):
    return HttpResponse("Order View Placeholder")


