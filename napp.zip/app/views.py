from django.shortcuts import render, redirect
from app.models.user.common import Users
from app.models.country import Country
from django.contrib import messages
from django.http import JsonResponse, HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt
import random
import json
from app.models.google import GoogleAccess
from google.oauth2.credentials import Credentials
import datetime
import os
import re
from django.conf import settings
from django.utils import timezone
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth import logout as django_logout


def landing(request):
    return render(request, 'index.html')

def signin_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        try:
            user = Users.objects.get(email=email, password=password)
            request.session['user_id'] = user.id
            request.session['user_type'] = user.user_type
            # Dashboard redirect logic (copied from dashboard_view)
            if user.user_type == 1:
                return redirect('/')
            elif user.user_type == 2:
                return redirect('/moderator/')
            elif user.user_type == 3:
                return redirect('/support/')
            elif user.user_type == 4:
                return redirect('/deliveryman/')
            elif user.user_type == 5:
                return redirect('/company/')
            elif user.user_type == 6:
                return redirect('/customer/')
            elif user.user_type == 9:
                return redirect('/guest/')
            else:
                return redirect('/signin')
        except Users.DoesNotExist:
            messages.error(request, 'Invalid credentials')
    return render(request, 'signin.html')

def signup_view(request):
    if request.method == 'POST':
        user_type = request.POST.get('user_type')
        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        phone = request.POST.get('phone_number')
        Users.objects.create(
            user_type=user_type, user_name=name, email=email,
            password=password, phone_number=phone
        )
        return redirect('/signin/')
    return render(request, 'signup.html')

def forgotpassword_view(request):
    return render(request, 'forgotpassword.html')

@csrf_exempt
def forgotpassword_api(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        email = data.get('email')
        if not email:
            return JsonResponse({'status': 'error', 'message': 'Email is required.'}, status=400)
        try:
            user = Users.objects.get(email=email)
            otp = random.randint(100000, 999999)
            request.session['reset_otp'] = str(otp)
            request.session['reset_email'] = email
            # In production, send OTP via email. Here, just return it for demo.
            return JsonResponse({'status': 'success', 'message': f'OTP sent to {email}. (Demo OTP: {otp})'})
        except Users.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'No user found with this email.'}, status=404)
    return HttpResponseBadRequest()

@csrf_exempt
def forgotpassword_otp_api(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        email = data.get('email')
        otp = data.get('otp')
        session_otp = request.session.get('reset_otp')
        session_email = request.session.get('reset_email')
        if not (email and otp):
            return JsonResponse({'status': 'error', 'message': 'Email and OTP are required.'}, status=400)
        if email != session_email:
            return JsonResponse({'status': 'error', 'message': 'Email does not match.'}, status=400)
        if otp != session_otp:
            return JsonResponse({'status': 'error', 'message': 'Invalid OTP.'}, status=400)
        request.session['otp_verified'] = True
        return JsonResponse({'status': 'success', 'message': 'OTP verified. You can now reset your password.'})
    return HttpResponseBadRequest()

@csrf_exempt
def forgotpassword_reset_api(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        email = data.get('email')
        new_password = data.get('newPassword')
        otp_verified = request.session.get('otp_verified')
        session_email = request.session.get('reset_email')
        if not (email and new_password):
            return JsonResponse({'status': 'error', 'message': 'Email and new password are required.'}, status=400)
        if not otp_verified or email != session_email:
            return JsonResponse({'status': 'error', 'message': 'OTP verification required.'}, status=400)
        try:
            user = Users.objects.get(email=email)
            user.password = new_password
            user.save()
            # Clear session
            request.session.pop('reset_otp', None)
            request.session.pop('reset_email', None)
            request.session.pop('otp_verified', None)
            return JsonResponse({'status': 'success', 'message': 'Password reset successful.'})
        except Users.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'User not found.'}, status=404)
    return HttpResponseBadRequest()

def dashboard_view(request):
    user_type = request.session.get('user_type')
    if user_type == 1:
        # Admin: redirect to root (admin panel)
        return redirect('/')
    elif user_type == 2:
        # Moderator: redirect to moderator dashboard
        return redirect('/moderator/')
    elif user_type == 3:
        # Support: redirect to support dashboard
        return redirect('/support/')
    elif user_type == 4:
        # DeliveryMan: redirect to deliveryman dashboard
        return redirect('/deliveryman/')
    elif user_type == 5:
        # Company: redirect to company dashboard
        return redirect('/company/')
    elif user_type == 6:
        # Customer: redirect to customer dashboard
        return redirect('/customer/')
    elif user_type == 9:
        # Guest: redirect to guest dashboard or homepage
        return redirect('/guest/')
    else:
        # Not logged in or unknown type
        return redirect('/signin')

@csrf_exempt
def signin_api(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            email = data.get('email')
            password = data.get('password')
            if not email or not password:
                return JsonResponse({'status': 'error', 'message': 'Email and password required.'}, status=400)
            from app.models.user.common import Users
            try:
                user = Users.objects.get(email=email)
                if not user.is_active:
                    return JsonResponse({'status': 'error', 'message': 'Account is not active.'}, status=403)
                if not check_password(password, user.password):
                    return JsonResponse({'status': 'error', 'message': 'Invalid credentials.'}, status=401)
                request.session['user_id'] = user.id
                request.session['user_type'] = user.user_type
                return JsonResponse({'status': 'success', 'message': 'Login successful!', 'usertype': user.user_type})
            except Users.DoesNotExist:
                return JsonResponse({'status': 'error', 'message': 'Invalid credentials.'}, status=401)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)
    return JsonResponse({'status': 'error', 'message': 'Invalid request method.'}, status=405)

def sanitize_filename(filename):
    # Replace spaces with hyphens
    filename = filename.replace(' ', '-')
    # Remove unwanted characters, allow only a-z, A-Z, 0-9, -, _
    filename = re.sub(r'[^a-zA-Z0-9\-_\.]', '', filename)
    return filename

def generate_username(name):
    # Only a-z, A-Z, 0-9, hyphen; space -> hyphen; all lowercase
    username = re.sub(r'[^a-zA-Z0-9\- ]', '', name)
    username = username.replace(' ', '-').lower()
    # Remove multiple hyphens
    username = re.sub(r'-+', '-', username).strip('-')
    # Add year day
    today = datetime.date.today()
    year_day = today.timetuple().tm_yday
    username = f"{username}-{year_day}"
    return username

@csrf_exempt
def signup_api(request):
    if request.method == 'POST':
        try:
            # Handle both JSON and multipart/form-data
            if request.content_type.startswith('multipart/form-data'):
                data = request.POST
                file = request.FILES.get('profile_image')
            else:
                data = json.loads(request.body)
                file = None

            user_type = int(data.get('user_type'))
            name = data.get('full_name')
            email = data.get('email')
            phone = data.get('phone_number')
            password = data.get('password')
            country_id = data.get('country_id')
            gender = data.get('gender')
            date_of_birth = data.get('date_of_birth')
            national_id = data.get('national_id')
            referral_code = data.get('referral_code')
            company_name = data.get('company_name')
            company_address = data.get('company_address')
            accept_terms = data.get('accept_terms')
            newsletter_subscribed = data.get('newsletter_subscribed', False)

            # Convert to boolean
            def to_bool(val):
                return str(val).lower() in ['true', '1', 'on']

            accept_terms = to_bool(accept_terms)
            newsletter_subscribed = to_bool(newsletter_subscribed)

            # Basic validation
            if not (user_type and name and email and password and country_id and accept_terms):
                return JsonResponse({'status': 'error', 'message': 'All required fields must be filled.'}, status=400)
            if user_type == 1:
                return JsonResponse({'status': 'error', 'message': 'Admin account creation is not allowed.'}, status=403)
            if Users.objects.filter(email=email).exists():
                return JsonResponse({'status': 'error', 'message': 'Email already exists.'}, status=400)

            is_active = True if user_type in [5, 6] else False

            # Handle image upload
            profile_image_path = None
            if file:
                now = timezone.now()
                upload_dir = os.path.join(settings.BASE_DIR, 'static', 'upload', str(now.year), f"{now.month:02d}")
                os.makedirs(upload_dir, exist_ok=True)
                original_name = file.name
                sanitized_name = sanitize_filename(original_name)
                base, ext = os.path.splitext(sanitized_name)
                counter = 1
                final_name = sanitized_name
                while os.path.exists(os.path.join(upload_dir, final_name)):
                    final_name = f"{base}-{counter}{ext}"
                    counter += 1
                file_path = os.path.join(upload_dir, final_name)
                with open(file_path, 'wb+') as destination:
                    for chunk in file.chunks():
                        destination.write(chunk)
                # Save relative path for DB (ImageField expects relative to MEDIA_ROOT or static)
                profile_image_path = f"upload/{now.year}/{now.month:02d}/{final_name}"

            # Username generation
            user_name = generate_username(name)

            # Hash the password before saving
            hashed_password = make_password(password)

            user = Users.objects.create(
                user_type=user_type,
                full_name=name,
                user_name=user_name,  # <-- generated username
                email=email,
                password=hashed_password,
                phone_number=phone,
                is_active=is_active,
                is_email_verified=False,
                is_phone_verified=False,
                gender=gender,
                date_of_birth=date_of_birth,
                national_id=national_id,
                referral_code=referral_code,
                company_name=company_name,
                company_address=company_address,
                newsletter_subscribed=newsletter_subscribed,
                country_id=country_id,  # <-- Save country_id directly
                profile_image=profile_image_path  # <-- Save image path if uploaded
            )
            return JsonResponse({'status': 'success', 'message': 'Signup successful! Please verify your email and phone.'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)
    return JsonResponse({'status': 'error', 'message': 'Invalid request method.'}, status=405)

@csrf_exempt
def getcountry(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
        except Exception:
            data = {}
        country_id = data.get('id')
        if country_id:
            try:
                country = Country.objects.get(id=country_id)
                result = {
                    'id': country.id,
                    'name': country.name,
                    'iso_alpha2': country.iso_alpha2,
                    'iso_alpha3': country.iso_alpha3,
                    'phone_code': country.phone_code,
                    'capital': country.capital,
                }
                return JsonResponse(result)
            except Country.DoesNotExist:
                return JsonResponse({'status': 'error', 'message': 'Country not found.'}, status=404)
        else:
            countries = Country.objects.all()
            result = [
                {
                    'id': c.id,
                    'name': c.name,
                    'iso_alpha2': c.iso_alpha2,
                    'iso_alpha3': c.iso_alpha3,
                    'phone_code': c.phone_code,
                    'capital': c.capital,
                }
                for c in countries
            ]
            return JsonResponse(result, safe=False)  # <-- Return as array, not wrapped in dict
    return JsonResponse({'status': 'error', 'message': 'Invalid request method.'}, status=405)

def get_gmail_credentials_from_db(email):
    try:
        obj = GoogleAccess.objects.get(email=email)
    except GoogleAccess.DoesNotExist:
        raise Exception(f'No credentials found for {email}. Please authorize first.')
    creds_json = obj.credentials
    creds = Credentials.from_authorized_user_info(json.loads(creds_json), SCOPES)
    return creds

def logout_view(request):
    """
    Log out the user by clearing the session and redirecting to signin.
    """
    request.session.flush()
    return redirect('/signin')
