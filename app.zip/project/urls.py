from django.contrib import admin
from django.urls import path, include
from app.views import landing, signin_view, signup_view, forgotpassword_view, logout_view
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import RedirectView

urlpatterns = [
    path('superadmin/', admin.site.urls),  # Enable Django admin at /superadmin/
    path('signin/', signin_view, name='signin'),
    path('signup/', signup_view, name='signup'),
    path('forgotpassword/', forgotpassword_view, name='forgotpassword'),
    path('company/', include('app.company_views.urls')),
    #path('customer/', include('app.customer_views.urls')),
    path('', include('app.admin_views.urls', namespace='main_admin')),
    path('logout', logout_view, name='logout_view'),
    path('api/', include('app.admin_views.urls_api', namespace='main_admin_api')),
    path('', include('app.urls')),  # Include app.urls for API endpoints
    path('favicon.ico', RedirectView.as_view(url='/static/favicon.ico', permanent=True)),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
