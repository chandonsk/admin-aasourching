from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def cms_pages_get(request):
    return JsonResponse({"status": "success", "message": "cms_pages_get placeholder"})

@csrf_exempt
def cms_pages_pagination(request):
    return JsonResponse({"status": "success", "message": "cms_pages_pagination placeholder"})

@csrf_exempt
def cms_pages_add(request):
    return JsonResponse({"status": "success", "message": "cms_pages_add placeholder"})

@csrf_exempt
def cms_pages_add_get(request):
    return JsonResponse({"status": "success", "message": "cms_pages_add_get placeholder"})

@csrf_exempt
def cms_pages_add_pagination(request):
    return JsonResponse({"status": "success", "message": "cms_pages_add_pagination placeholder"})

@csrf_exempt
def cms_pages_add_add(request):
    return JsonResponse({"status": "success", "message": "cms_pages_add_add placeholder"})

@csrf_exempt
def cms_category_get(request):
    return JsonResponse({"status": "success", "message": "cms_category_get placeholder"})

@csrf_exempt
def cms_category_pagination(request):
    return JsonResponse({"status": "success", "message": "cms_category_pagination placeholder"})

@csrf_exempt
def cms_category_add(request):
    return JsonResponse({"status": "success", "message": "cms_category_add placeholder"})

@csrf_exempt
def cms_pages_edit(request):
    return JsonResponse({"status": "success", "message": "cms_pages_edit placeholder"})

@csrf_exempt
def cms_pages_delete(request):
    return JsonResponse({"status": "success", "message": "cms_pages_delete placeholder"})

@csrf_exempt
def cms_pages_add_edit(request):
    return JsonResponse({"status": "success", "message": "cms_pages_add_edit placeholder"})

@csrf_exempt
def cms_pages_add_delete(request):
    return JsonResponse({"status": "success", "message": "cms_pages_add_delete placeholder"})

@csrf_exempt
def cms_category_edit(request):
    return JsonResponse({"status": "success", "message": "cms_category_edit placeholder"})

@csrf_exempt
def cms_category_delete(request):
    return JsonResponse({"status": "success", "message": "cms_category_delete placeholder"})
