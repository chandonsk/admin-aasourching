from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def cms_menus_get(request):
    return JsonResponse({"status": "success", "message": "cms_menus_get placeholder"})

@csrf_exempt
def cms_menus_pagination(request):
    return JsonResponse({"status": "success", "message": "cms_menus_pagination placeholder"})

@csrf_exempt
def cms_menus_add(request):
    return JsonResponse({"status": "success", "message": "cms_menus_add placeholder"})

@csrf_exempt
def cms_menus_add_get(request):
    return JsonResponse({"status": "success", "message": "cms_menus_add_get placeholder"})

@csrf_exempt
def cms_menus_add_pagination(request):
    return JsonResponse({"status": "success", "message": "cms_menus_add_pagination placeholder"})

@csrf_exempt
def cms_menus_add_add(request):
    return JsonResponse({"status": "success", "message": "cms_menus_add_add placeholder"})

@csrf_exempt
def menu_category_get(request):
    return JsonResponse({"status": "success", "message": "menu_category_get placeholder"})

@csrf_exempt
def menu_category_pagination(request):
    return JsonResponse({"status": "success", "message": "menu_category_pagination placeholder"})

@csrf_exempt
def menu_category_add(request):
    return JsonResponse({"status": "success", "message": "menu_category_add placeholder"})

@csrf_exempt
def cms_menus_edit(request):
    return JsonResponse({"status": "success", "message": "cms_menus_edit placeholder"})

@csrf_exempt
def cms_menus_delete(request):
    return JsonResponse({"status": "success", "message": "cms_menus_delete placeholder"})

@csrf_exempt
def cms_menus_add_edit(request):
    return JsonResponse({"status": "success", "message": "cms_menus_add_edit placeholder"})

@csrf_exempt
def cms_menus_add_delete(request):
    return JsonResponse({"status": "success", "message": "cms_menus_add_delete placeholder"})

@csrf_exempt
def menu_category_edit(request):
    return JsonResponse({"status": "success", "message": "menu_category_edit placeholder"})

@csrf_exempt
def menu_category_delete(request):
    return JsonResponse({"status": "success", "message": "menu_category_delete placeholder"})
