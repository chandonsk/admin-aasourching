# blogs_api.py
# Add your API blog-related view functions here.

from app.models.cms.blog import Blog, BlogCategory
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.forms.models import model_to_dict
from django.db.models import Q
from app.models.upload import ImageByToken
import os
import shutil
from django.conf import settings
from datetime import datetime
import json


# Correct status_map for Blog.status (model: 1=Published, 2=Draft, 3=Archived)
status_map = {
    'Published': '1',
    'Draft': '2',
    'Archived': '3'
}

@csrf_exempt
def blogs_get(request):
    """
    Get paginated blogs list.
    Query params: page, page_size, search (optional)
    """
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    search = request.GET.get('search', '').strip()
    qs = Blog.objects.all().order_by('-created_at')
    if search:
        qs = qs.filter(Q(title__icontains=search) | Q(content__icontains=search))
    total = qs.count()
    total_pages = (total + page_size - 1) // page_size
    start = (page - 1) * page_size
    end = start + page_size
    results = []
    for blog in qs[start:end]:
        # Only send first 120 chars of content (preserving HTML tags, not stripping)
        short_content = blog.content[:120] if blog.content else ''
        results.append({
            'id': blog.id,
            'title': blog.title,
            'category': blog.category.name if blog.category else '',
            'category_id': blog.category.id if blog.category else None,
            'image': blog.image.url if blog.image else '',
            'content': short_content,
            'status': dict(Blog.STATUS_CHOICES).get(blog.status, blog.status),
            'status_code': blog.status,
            'meta_title': blog.meta_title,
            'meta_description': blog.meta_description,
            'created_at': blog.created_at.strftime('%Y-%m-%d %H:%M'),
        })
    return JsonResponse({
        'status': 'success',
        'results': results,
        'total': total,
        'page': page,
        'page_size': page_size,
        'total_pages': total_pages
    })

@csrf_exempt
def blogs_pagination(request):
    return JsonResponse({"status": "success", "message": "blogs_pagination placeholder"})

@csrf_exempt
def blogs_add(request):
    if request.method != 'POST':
        return JsonResponse({"status": "error", "message": "POST required"})
    try:
        title = request.POST.get('title', '').strip()
        category_id = request.POST.get('category', '').strip()
        content = request.POST.get('content', '').strip()
        status = request.POST.get('status', '1').strip()
        meta_title = request.POST.get('meta_title', '').strip()
        meta_description = request.POST.get('meta_description', '').strip()
        image_token = request.POST.get('image_path', '').strip()
        # Validate
        if not title:
            return JsonResponse({"status": "error", "message": "Title is required"})
        if not category_id:
            return JsonResponse({"status": "error", "message": "Category is required"})
        if not content:
            return JsonResponse({"status": "error", "message": "Content is required"})
        # Map status string or code to Blog model status
        blog_status = status_map.get(status, '1')
        try:
            category = BlogCategory.objects.get(id=category_id)
        except BlogCategory.DoesNotExist:
            return JsonResponse({"status": "error", "message": "Invalid category"})
        blog = Blog(
            title=title,
            category=category,
            content=content,
            status=blog_status,
            meta_title=meta_title,
            meta_description=meta_description
        )
        # Handle image token and move/copy image if needed
        if image_token:
            # Try to get ImageByToken
            img_obj = ImageByToken.objects.filter(token=image_token).first()
            if img_obj and img_obj.image_path:
                old_path = img_obj.image_path
                # Only handle /static/upload/....png
                if old_path.startswith('/static/upload/'):
                    # Extract date parts from path if possible
                    try:
                        parts = old_path.split('/')
                        year = parts[3]
                        month = parts[4]
                    except Exception:
                        now = datetime.now()
                        year = now.strftime('%Y')
                        month = now.strftime('%m')
                    filename = os.path.basename(old_path)
                    new_rel_path = f'/static/cms/blog/{year}/{month}/{filename}'
                    # Absolute paths
                    old_abs = os.path.join(settings.BASE_DIR, old_path.lstrip('/'))
                    new_abs = os.path.join(settings.BASE_DIR, new_rel_path.lstrip('/'))
                    os.makedirs(os.path.dirname(new_abs), exist_ok=True)
                    # Move/copy file
                    shutil.move(old_abs, new_abs)
                    blog.image = new_rel_path
                else:
                    blog.image = old_path  # fallback, if not /static/upload
            else:
                # If not token, maybe it's already a path
                blog.image = image_token
        blog.save()
        return JsonResponse({"status": "success", "message": "Blog added", "id": blog.id})
    except Exception as e:
        return JsonResponse({"status": "error", "message": str(e)})

@csrf_exempt
def blogs_add_get(request):
    return JsonResponse({"status": "success", "message": "blogs_add_get placeholder"})

@csrf_exempt
def blogs_add_pagination(request):
    return JsonResponse({"status": "success", "message": "blogs_add_pagination placeholder"})

@csrf_exempt
def blogs_add_add(request):
    return JsonResponse({"status": "success", "message": "blogs_add_add placeholder"})

@csrf_exempt
def blogs_add_edit(request):
    return JsonResponse({"status": "success", "message": "blogs_add_edit placeholder"})

@csrf_exempt
def blogs_add_delete(request):
    return JsonResponse({"status": "success", "message": "blogs_add_delete placeholder"})

@csrf_exempt
def blogs_edit(request):
    if request.method != 'POST':
        return JsonResponse({"status": "error", "message": "POST required"})
    try:
        data = request.POST if request.POST else json.loads(request.body.decode())
        blog_id = data.get('id')
        title = data.get('title', '').strip()
        category_id = data.get('category', '').strip()
        content = data.get('content', '').strip()
        status = data.get('status', '').strip()
        meta_title = request.POST.get('meta_title', '').strip()
        meta_description = request.POST.get('meta_description', '').strip()
        image_token = data.get('image_path', '').strip()
        if not blog_id:
            return JsonResponse({"status": "error", "message": "Blog ID required"})
        blog = Blog.objects.filter(id=blog_id).first()
        if not blog:
            return JsonResponse({"status": "error", "message": "Blog not found"})
        if title:
            blog.title = title
        if category_id:
            try:
                category = BlogCategory.objects.get(id=category_id)
                blog.category = category
            except BlogCategory.DoesNotExist:
                return JsonResponse({"status": "error", "message": "Invalid category"})
        if content:
            blog.content = content
        if status:
            blog.status = status_map.get(status, blog.status)
        if meta_title:
            blog.meta_title = meta_title
        if meta_description:
            blog.meta_description = meta_description
        # Handle image_token like blogs_add
        if image_token:
            img_obj = ImageByToken.objects.filter(token=image_token).first()
            if img_obj and img_obj.image_path:
                old_path = img_obj.image_path
                if old_path.startswith('/static/upload/'):
                    try:
                        parts = old_path.split('/')
                        year = parts[3]
                        month = parts[4]
                    except Exception:
                        now = datetime.now()
                        year = now.strftime('%Y')
                        month = now.strftime('%m')
                    filename = os.path.basename(old_path)
                    new_rel_path = f'/static/cms/blog/{year}/{month}/{filename}'
                    old_abs = os.path.join(settings.BASE_DIR, old_path.lstrip('/'))
                    new_abs = os.path.join(settings.BASE_DIR, new_rel_path.lstrip('/'))
                    os.makedirs(os.path.dirname(new_abs), exist_ok=True)
                    shutil.move(old_abs, new_abs)
                    blog.image = new_rel_path
                else:
                    blog.image = old_path
            else:
                blog.image = image_token
        blog.save()
        return JsonResponse({"status": "success", "message": "Blog updated"})
    except Exception as e:
        return JsonResponse({"status": "error", "message": str(e)})

@csrf_exempt
def blogs_delete(request):
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'message': 'POST required'})
    try:
        data = request.POST if request.POST else json.loads(request.body.decode())
        blog_id = data.get('id')
        if not blog_id:
            return JsonResponse({'status': 'error', 'message': 'Blog ID required'})
        blog = Blog.objects.filter(id=blog_id).first()
        if not blog:
            return JsonResponse({'status': 'error', 'message': 'Blog not found'})
        blog.delete()
        return JsonResponse({'status': 'success', 'message': 'Blog deleted'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})

@csrf_exempt
def blogs_category_pagination(request, blog_id=None):
    return JsonResponse({"status": "success", "message": f"blogs_category_pagination placeholder for blog_id {blog_id}"})

@csrf_exempt
def blogs_category_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    qs = BlogCategory.objects.all().order_by('-id')
    total = qs.count()
    total_pages = (total + page_size - 1) // page_size
    start = (page - 1) * page_size
    end = start + page_size
    results = []
    for cat in qs[start:end]:
        results.append({
            'id': cat.id,
            'name': cat.name,
            'description': cat.description,
            'status': 'Active' if cat.status == '1' else 'Inactive',
        })
    return JsonResponse({
        'status': 'success',
        'results': results,
        'total': total,
        'page': page,
        'page_size': page_size,
        'total_pages': total_pages
    })

@csrf_exempt
def blogs_category_add(request):
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'message': 'POST required'})
    try:
        data = json.loads(request.body.decode())
        name = data.get('name', '').strip()
        description = data.get('description', '').strip()
        status = data.get('status', '1')
        if not name:
            return JsonResponse({'status': 'error', 'message': 'Name is required'})
        if BlogCategory.objects.filter(name=name).exists():
            return JsonResponse({'status': 'error', 'message': 'Category already exists'})
        cat = BlogCategory.objects.create(name=name, description=description, status=status)
        return JsonResponse({'status': 'success', 'message': 'Category added', 'id': cat.id})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})

@csrf_exempt
def blogs_category_edit(request):
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'message': 'POST required'})
    try:
        data = json.loads(request.body.decode())
        cat_id = data.get('id')
        name = data.get('name', '').strip()
        description = data.get('description', '').strip()
        status = data.get('status', '1')
        if not cat_id:
            return JsonResponse({'status': 'error', 'message': 'ID required'})
        cat = BlogCategory.objects.filter(id=cat_id).first()
        if not cat:
            return JsonResponse({'status': 'error', 'message': 'Category not found'})
        if not name:
            return JsonResponse({'status': 'error', 'message': 'Name is required'})
        if BlogCategory.objects.exclude(id=cat_id).filter(name=name).exists():
            return JsonResponse({'status': 'error', 'message': 'Category with this name already exists'})
        cat.name = name
        cat.description = description
        cat.status = status
        cat.save()
        return JsonResponse({'status': 'success', 'message': 'Category updated'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})


@csrf_exempt
def blogs_category_delete(request):
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'message': 'POST required'})
    try:
        data = json.loads(request.body.decode())
        cat_id = data.get('id')
        if not cat_id:
            return JsonResponse({'status': 'error', 'message': 'ID required'})
        cat = BlogCategory.objects.filter(id=cat_id).first()
        if not cat:
            return JsonResponse({'status': 'error', 'message': 'Category not found'})
        cat.delete()
        return JsonResponse({'status': 'success', 'message': 'Category deleted'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})

@csrf_exempt
def blogs_detail(request, blog_id):
    try:
        blog = Blog.objects.filter(id=blog_id).first()
        if not blog:
            return JsonResponse({'status': 'error', 'message': 'Blog not found'}, status=404)
        data = {
            'id': blog.id,
            'title': blog.title,
            'category': blog.category.name if blog.category else '',
            'category_id': blog.category.id if blog.category else None,
            'image': blog.image.url if blog.image else '',
            'content': blog.content,
            'status': dict(Blog.STATUS_CHOICES).get(blog.status, blog.status),
            'meta_title': blog.meta_title,
            'meta_description': blog.meta_description,
            'status_code': blog.status,
            'created_at': blog.created_at.strftime('%Y-%m-%d %H:%M'),
        }
        return JsonResponse({'status': 'success', 'blog': data})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
