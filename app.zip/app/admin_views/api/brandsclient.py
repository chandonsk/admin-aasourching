# brandsclients_api.py

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from app.models.brandclient import BrandClient
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from app.models.upload import ImageByToken
from django.conf import settings
import os
import shutil
import json
from django.db import models

def brandclient_to_dict(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "website": obj.website,
        "email": obj.email,
        "phone": obj.phone,
        "avatar": obj.avatar.url if obj.avatar else "",
        "status": obj.status,
        "created_at": obj.created_at.strftime("%Y-%m-%d %H:%M"),
    }

def set_brandclient_avatar_from_token(bc, token):
    if not token:
        return
    try:
        img_token = ImageByToken.objects.get(token=token)
        old_path = img_token.image_path  # e.g. /static/upload/2025/06/filename.png
        if old_path.startswith('/static/upload/'):
            try:
                parts = old_path.split('/')
                year = parts[3]
                month = parts[4]
            except Exception:
                from datetime import datetime
                now = datetime.now()
                year = now.strftime('%Y')
                month = now.strftime('%m')
            filename = os.path.basename(old_path)
            new_rel_path = f'/static/brandclient_avatars/{year}/{month}/{filename}'
            old_abs = os.path.join(settings.BASE_DIR, old_path.lstrip('/'))
            new_abs = os.path.join(settings.BASE_DIR, new_rel_path.lstrip('/'))
            os.makedirs(os.path.dirname(new_abs), exist_ok=True)
            shutil.move(old_abs, new_abs)
            bc.avatar = new_rel_path  # Save with leading /static/...
        else:
            bc.avatar = old_path  # fallback
        bc.save()
        img_token.delete()
    except Exception as e:
        # Optionally log error
        pass

@csrf_exempt
def brandsclients_get(request):
    """
    Get paginated brands/clients list.
    Query params: page, page_size, search (optional)
    """
    try:
        page = int(request.GET.get('page', 1))
    except Exception:
        page = 1
    try:
        page_size = int(request.GET.get('page_size', 10))
    except Exception:
        page_size = 10
    search = request.GET.get('search', '').strip()
    qs = BrandClient.objects.exclude(status='-1').order_by('-created_at')
    if search:
        qs = qs.filter(
            models.Q(name__icontains=search) |
            models.Q(email__icontains=search) |
            models.Q(phone__icontains=search)
        )
    total = qs.count()
    total_pages = (total + page_size - 1) // page_size
    start = (page - 1) * page_size
    end = start + page_size
    results = [brandclient_to_dict(bc) for bc in qs[start:end]]
    return JsonResponse({
        "status": "success",
        "results": results,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": total_pages
    })

@csrf_exempt
def brandsclients_pagination(request):
    return JsonResponse({"status": "success", "message": "brandsclients_pagination placeholder"})

@csrf_exempt
def brandsclients_add(request):
    if request.method == "POST":
        data = request.POST
        name = data.get("name")
        website = data.get("website")
        email = data.get("email")
        phone = data.get("phone")
        status = data.get("status", "1")
        avatar_token = data.get("avatar_token")
        # Ignore avatar file if avatar_token is present
        if not name or not email or not phone:
            return JsonResponse({"status": "error", "message": "Name, Email, and Phone are required."})
        bc = BrandClient(
            name=name,
            website=website,
            email=email,
            phone=phone,
            status=status,
        )
        bc.save()
        if avatar_token:
            set_brandclient_avatar_from_token(bc, avatar_token)
        # Do not process request.FILES['avatar'] if avatar_token is present
        return JsonResponse({"status": "success", "message": "Brand/Client added.", "result": brandclient_to_dict(bc)})
    return JsonResponse({"status": "error", "message": "Invalid request."})

@csrf_exempt
def brandsclients_edit(request):
    if request.method == "POST":
        data = request.POST
        id = data.get("id")
        try:
            bc = BrandClient.objects.get(id=id)
        except BrandClient.DoesNotExist:
            return JsonResponse({"status": "error", "message": "Not found."})
        bc.name = data.get("name", bc.name)
        bc.website = data.get("website", bc.website)
        bc.email = data.get("email", bc.email)
        bc.phone = data.get("phone", bc.phone)
        bc.status = data.get("status", bc.status)
        bc.save()
        avatar_token = data.get("avatar_token")
        if avatar_token:
            set_brandclient_avatar_from_token(bc, avatar_token)
        # If no avatar_token, do not change avatar
        return JsonResponse({"status": "success", "message": "Updated.", "result": brandclient_to_dict(bc)})
    return JsonResponse({"status": "error", "message": "Invalid request."})

@csrf_exempt
def brandsclients_delete(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            id = data.get("id")
        except Exception:
            id = request.POST.get("id")
        try:
            bc = BrandClient.objects.get(id=id)
        except BrandClient.DoesNotExist:
            return JsonResponse({"status": "error", "message": "Not found."})
        bc.status = "-1"
        bc.save()
        return JsonResponse({"status": "success", "message": "Deleted."})
    return JsonResponse({"status": "error", "message": "Invalid request."})

@csrf_exempt
def brandsclients_avatar_upload(request):
    # For AJAX avatar upload (like blogs/add.html)
    if request.method == "POST" and request.FILES.get("file"):
        file = request.FILES["file"]
        path = default_storage.save(f"brandclient_avatars/{file.name}", ContentFile(file.read()))
        url = default_storage.url(path)
        return JsonResponse({"status": "success", "path": url})
    return JsonResponse({"status": "error", "message": "No file uploaded."})

