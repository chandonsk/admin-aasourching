from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from app.models.product.sustainability import ProductSustainability
import json

def serialize_sustainability(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "desc": obj.description,
        "status": "Active" if obj.status == "1" else "Inactive"
    }

def paginate_queryset(qs, page, page_size):
    total = qs.count()
    start = (page - 1) * page_size
    end = start + page_size
    results = list(qs[start:end])
    return results, total

@csrf_exempt
def products_sustainability_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    qs = ProductSustainability.objects.all().order_by('-id')
    results, total = paginate_queryset(qs, page, page_size)
    data = [serialize_sustainability(obj) for obj in results]
    return JsonResponse({
        "results": data,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size
    })

@csrf_exempt
def products_sustainability_pagination(request):
    return products_sustainability_get(request)

@csrf_exempt
def products_sustainability_add(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            name = data.get("name", "").strip()
            description = data.get("description", "").strip()
            status = data.get("status", "Active")
            status_val = "1" if status == "Active" else "0"
            if not name:
                return JsonResponse({"status": "error", "message": "Name is required."}, status=400)
            if ProductSustainability.objects.filter(name=name).exists():
                return JsonResponse({"status": "error", "message": "Name already exists."}, status=400)
            obj = ProductSustainability.objects.create(
                name=name,
                description=description,
                status=status_val
            )
            return JsonResponse({"status": "success", "message": "Sustainability type added.", "id": obj.id})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=400)
    return JsonResponse({"status": "error", "message": "Invalid request."}, status=405)

@csrf_exempt
def products_sustainability_edit(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            obj_id = data.get("id")
            name = data.get("name", "").strip()
            description = data.get("description", "").strip()
            status = data.get("status", "Active")
            status_val = "1" if status == "Active" else "0"
            if not obj_id:
                return JsonResponse({"status": "error", "message": "ID is required."}, status=400)
            obj = ProductSustainability.objects.filter(id=obj_id).first()
            if not obj:
                return JsonResponse({"status": "error", "message": "Not found."}, status=404)
            if name:
                # Prevent duplicate name for other records
                if ProductSustainability.objects.exclude(id=obj_id).filter(name=name).exists():
                    return JsonResponse({"status": "error", "message": "Name already exists."}, status=400)
                obj.name = name
            obj.description = description
            obj.status = status_val
            obj.save()
            return JsonResponse({"status": "success", "message": "Sustainability type updated."})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=400)
    return JsonResponse({"status": "error", "message": "Invalid request."}, status=405)

@csrf_exempt
def products_sustainability_delete(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            obj_id = data.get("id")
            if not obj_id:
                return JsonResponse({"status": "error", "message": "ID is required."}, status=400)
            obj = ProductSustainability.objects.filter(id=obj_id).first()
            if not obj:
                return JsonResponse({"status": "error", "message": "Not found."}, status=404)
            obj.delete()
            return JsonResponse({"status": "success", "message": "Sustainability type deleted."})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=400)
    return JsonResponse({"status": "error", "message": "Invalid request."}, status=405)
