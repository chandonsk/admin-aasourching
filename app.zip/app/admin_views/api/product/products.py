from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import os
from django.conf import settings
from django.views.decorators.http import require_POST
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from django.utils import timezone
import re
from app.models.product.products import ImageByToken
from app.models.upload import ImageByToken
from app.models.product.products import Products, ProductDetails, ProductMeta
from app.models.product.categories import ProductCategory
from app.models.product.fit import ProductFit
from app.models.product.lines import ProductLine
from django.db import transaction
from datetime import datetime
import shutil
import uuid
import json

def paginate_queryset(qs, page, page_size):
    total = qs.count()
    start = (page - 1) * page_size
    end = start + page_size
    results = list(qs[start:end])
    return results, total

# ALL PRODUCTS
@csrf_exempt
def products_get(request):
    """
    Get paginated products list.
    Query params: page, page_size, search (optional)
    """
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    search = request.GET.get('search', '').strip()
    qs = Products.objects.all().order_by('-id')
    if search:
        from django.db.models import Q
        qs = qs.filter(
            Q(product_name__icontains=search) |
            Q(product_code__icontains=search)
        )
    total = qs.count()
    total_pages = (total + page_size - 1) // page_size
    start = (page - 1) * page_size
    end = start + page_size
    results = []

    # Batch fetch all related objects for mapping
    product_ids = list(qs[start:end].values_list('id', flat=True))
    # Get all unique ids for related fields
    productline_ids = set(qs[start:end].values_list('productline_id', flat=True))
    category_ids = set(qs[start:end].values_list('category_id', flat=True))
    fit_ids = set(qs[start:end].values_list('fit_id', flat=True))

    # Build id->name maps
    productline_map = {obj.id: obj.name for obj in ProductLine.objects.filter(id__in=productline_ids)}
    category_map = {obj.id: obj.name for obj in ProductCategory.objects.filter(id__in=category_ids)}
    fit_map = {obj.id: obj.name for obj in ProductFit.objects.filter(id__in=fit_ids)}

    for prod in qs[start:end]:
        productline_name = productline_map.get(prod.productline_id, "")
        category_name = category_map.get(prod.category_id, "")
        fit_name = fit_map.get(prod.fit_id, "")
        gender_display = dict(Products.GENDER_CHOICES).get(prod.gender, '')
        results.append({
            'id': prod.id,
            'product_name': prod.product_name,
            'product_code': prod.product_code,
            'productline_id': prod.productline_id,
            'productline_name': productline_name,
            'category_id': prod.category_id,
            'category_name': category_name,
            'fit_id': prod.fit_id,
            'fit_name': fit_name,
            'gsm': prod.gsm,
            'gender': prod.gender,
            'gender_display': gender_display,
            'is_active': prod.is_active,
            'product_image': prod.product_image,
        })
    return JsonResponse({
        'results': results,
        'total': total,
        'page': page,
        'page_size': page_size,
        'total_pages': total_pages
    })

@csrf_exempt
def products_pagination(request):
    return products_get(request)

@csrf_exempt
def products_add(request):
    if request.method != 'POST':
        return JsonResponse({"status": "error", "message": "POST required"})
    try:
        # Basic fields
        product_name = request.POST.get('product_name', '').strip()
        product_code = request.POST.get('product_code', '').strip()
        product_line = request.POST.get('product_line', '').strip()
        category = request.POST.get('category', '').strip()
        description = request.POST.get('description', '').strip()
        fit = request.POST.get('fit', '').strip()
        gsm = request.POST.get('gsm', '').strip()
        gender = request.POST.get('gender', '').strip()
        sustainability = request.POST.get('sustainability', '').strip()
        min_size = request.POST.get('min_size', '').strip()
        max_size = request.POST.get('max_size', '').strip()
        is_highlighted = bool(request.POST.get('highlight_product'))
        is_featured = bool(request.POST.get('is_featured'))

        # Details fields
        details_description = request.POST.get('details_description', '').strip()
        printing_embroidery = request.POST.get('printing_embroidery', '').strip()
        textile_care = request.POST.get('textile_care', '').strip()
        packaging = request.POST.get('packaging', '').strip()
        counterparts = request.POST.get('counterparts', '').strip()

        # Meta fields
        meta_title = request.POST.get('meta_title', '').strip()
        meta_description = request.POST.get('meta_description', '').strip()
        meta_keywords = request.POST.get('meta_keywords', '').strip()
        meta_robots_index = request.POST.get('meta_robots_index', 'index').strip()
        meta_robots_follow = request.POST.get('meta_robots_follow', 'follow').strip()
        meta_canonical = request.POST.get('meta_canonical', '').strip()
        og_title = request.POST.get('og_title', '').strip()
        og_description = request.POST.get('og_description', '').strip()
        og_url = request.POST.get('og_url', '').strip()
        og_type = request.POST.get('og_type', 'product').strip()
        twitter_card = request.POST.get('twitter_card', 'summary_large_image').strip()
        twitter_title = request.POST.get('twitter_title', '').strip()
        twitter_description = request.POST.get('twitter_description', '').strip()

        # Image tokens
        main_image_token = request.POST.get('main_image_token', '').strip()
        meta_image_token = request.POST.get('meta_image_token', '').strip()
        size_spec_token = request.POST.get('size_spec_token', '').strip()
        other_images_tokens = request.POST.get('other_images_tokens', '').strip().split(',') if request.POST.get('other_images_tokens') else []
        certificate_images_tokens = request.POST.get('certificate_images_tokens', '').strip().split(',') if request.POST.get('certificate_images_tokens') else []

        # Validate required
        if not product_name or not product_code or not product_line or not category:
            return JsonResponse({"status": "error", "message": "Required fields missing"})

        # --- Handle main image ---
        main_image_path = ''
        if main_image_token:
            img_obj = ImageByToken.objects.filter(token=main_image_token).first()
            if img_obj and img_obj.image_path:
                old_path = img_obj.image_path
                if old_path.startswith('/static/upload/'):
                    try:
                        parts = old_path.split('/')
                        year = parts[3]
                        month = parts[4]
                    except Exception:
                        now = datetime.now()
                        year = now.strftime('%Y')
                        month = now.strftime('%m')
                    filename = os.path.basename(old_path)
                    new_rel_path = f'/static/product/{year}/{month}/{filename}'
                    old_abs = os.path.join(settings.BASE_DIR, old_path.lstrip('/'))
                    new_abs = os.path.join(settings.BASE_DIR, new_rel_path.lstrip('/'))
                    os.makedirs(os.path.dirname(new_abs), exist_ok=True)
                    shutil.move(old_abs, new_abs)
                    main_image_path = new_rel_path
                else:
                    main_image_path = old_path
            else:
                main_image_path = main_image_token

        # --- Handle meta image ---
        meta_image_path = ''
        if meta_image_token:
            img_obj = ImageByToken.objects.filter(token=meta_image_token).first()
            if img_obj and img_obj.image_path:
                old_path = img_obj.image_path
                if old_path.startswith('/static/upload/'):
                    try:
                        parts = old_path.split('/')
                        year = parts[3]
                        month = parts[4]
                    except Exception:
                        now = datetime.now()
                        year = now.strftime('%Y')
                        month = now.strftime('%m')
                    filename = os.path.basename(old_path)
                    new_rel_path = f'/static/product/{year}/{month}/{filename}'
                    old_abs = os.path.join(settings.BASE_DIR, old_path.lstrip('/'))
                    new_abs = os.path.join(settings.BASE_DIR, new_rel_path.lstrip('/'))
                    os.makedirs(os.path.dirname(new_abs), exist_ok=True)
                    shutil.move(old_abs, new_abs)
                    meta_image_path = new_rel_path
                else:
                    meta_image_path = old_path
            else:
                meta_image_path = meta_image_token

        # --- Handle size spec image ---
        size_spec_path = ''
        if size_spec_token:
            img_obj = ImageByToken.objects.filter(token=size_spec_token).first()
            if img_obj and img_obj.image_path:
                old_path = img_obj.image_path
                if old_path.startswith('/static/upload/'):
                    try:
                        parts = old_path.split('/')
                        year = parts[3]
                        month = parts[4]
                    except Exception:
                        now = datetime.now()
                        year = now.strftime('%Y')
                        month = now.strftime('%m')
                    filename = os.path.basename(old_path)
                    new_rel_path = f'/static/product/{year}/{month}/{filename}'
                    old_abs = os.path.join(settings.BASE_DIR, old_path.lstrip('/'))
                    new_abs = os.path.join(settings.BASE_DIR, new_rel_path.lstrip('/'))
                    os.makedirs(os.path.dirname(new_abs), exist_ok=True)
                    shutil.move(old_abs, new_abs)
                    size_spec_path = new_rel_path
                else:
                    size_spec_path = old_path
            else:
                size_spec_path = size_spec_token

        # --- Handle other images (multi) ---
        other_images_paths = []
        for token in other_images_tokens:
            token = token.strip()
            if not token:
                continue
            img_obj = ImageByToken.objects.filter(token=token).first()
            if img_obj and img_obj.image_path:
                old_path = img_obj.image_path
                if old_path.startswith('/static/upload/'):
                    try:
                        parts = old_path.split('/')
                        year = parts[3]
                        month = parts[4]
                    except Exception:
                        now = datetime.now()
                        year = now.strftime('%Y')
                        month = now.strftime('%m')
                    filename = os.path.basename(old_path)
                    new_rel_path = f'/static/product/{year}/{month}/{filename}'
                    old_abs = os.path.join(settings.BASE_DIR, old_path.lstrip('/'))
                    new_abs = os.path.join(settings.BASE_DIR, new_rel_path.lstrip('/'))
                    os.makedirs(os.path.dirname(new_abs), exist_ok=True)
                    shutil.move(old_abs, new_abs)
                    other_images_paths.append(new_rel_path)
                else:
                    other_images_paths.append(old_path)
            else:
                other_images_paths.append(token)

        # --- Handle certificate images (multi) ---
        certificate_images_paths = []
        for token in certificate_images_tokens:
            token = token.strip()
            if not token:
                continue
            img_obj = ImageByToken.objects.filter(token=token).first()
            if img_obj and img_obj.image_path:
                old_path = img_obj.image_path
                if old_path.startswith('/static/upload/'):
                    try:
                        parts = old_path.split('/')
                        year = parts[3]
                        month = parts[4]
                    except Exception:
                        now = datetime.now()
                        year = now.strftime('%Y')
                        month = now.strftime('%m')
                    filename = os.path.basename(old_path)
                    new_rel_path = f'/static/product/{year}/{month}/{filename}'
                    old_abs = os.path.join(settings.BASE_DIR, old_path.lstrip('/'))
                    new_abs = os.path.join(settings.BASE_DIR, new_rel_path.lstrip('/'))
                    os.makedirs(os.path.dirname(new_abs), exist_ok=True)
                    shutil.move(old_abs, new_abs)
                    certificate_images_paths.append(new_rel_path)
                else:
                    certificate_images_paths.append(old_path)
            else:
                certificate_images_paths.append(token)

        # Save product, details, meta
        with transaction.atomic():
            product = Products.objects.create(
                product_name=product_name,
                product_code=product_code,
                productline_id=product_line,
                category_id=category,
                specifications=description,
                fit_id=fit or None,
                gsm=gsm,
                gender=gender or 1,
                sustainability_id=sustainability or None,
                min_size_id=min_size or None,
                max_size_id=max_size or None,
                is_highlighted=is_highlighted,
                is_featured=is_featured,
                product_image=main_image_path,
                product_images=other_images_paths,
            )
            ProductDetails.objects.create(
                product=product,
                product_details=details_description,
                printing_options=printing_embroidery,
                textile_care=textile_care,
                packaging=packaging,
                counterparts=counterparts,
                sizeSpecificationImage=size_spec_path,
            )
            ProductMeta.objects.create(
                product=product,
                meta_title=meta_title,
                meta_description=meta_description,
                meta_keywords=meta_keywords,
                meta_robots_index=meta_robots_index,
                meta_robots_follow=meta_robots_follow,
                meta_canonical=meta_canonical,
                meta_image=meta_image_path,
                og_title=og_title,
                og_description=og_description,
                og_url=og_url,
                og_type=og_type,
                twitter_card=twitter_card,
                twitter_title=twitter_title,
                twitter_description=twitter_description,
            )

        return JsonResponse({"status": "success", "message": "Product added.", "id": product.id})
    except Exception as e:
        return JsonResponse({"status": "error", "message": str(e)})

@csrf_exempt
def products_edit(request):
    if request.method != 'POST':
        return JsonResponse({"status": "error", "message": "POST required"})
    try:
        data = request.POST if request.POST else json.loads(request.body.decode())
        product_id = data.get('id')
        if not product_id:
            return JsonResponse({"status": "error", "message": "Product ID required"})
        product = Products.objects.filter(id=product_id).first()
        if not product:
            return JsonResponse({"status": "error", "message": "Product not found"})

        # Basic fields
        product_name = data.get('product_name', '').strip()
        product_code = data.get('product_code', '').strip()
        product_line = data.get('product_line', '').strip()
        category = data.get('category', '').strip()
        description = data.get('description', '').strip()
        fit = data.get('fit', '').strip()
        gsm = data.get('gsm', '').strip()
        gender = data.get('gender', '').strip()
        sustainability = data.get('sustainability', '').strip()
        min_size = data.get('min_size', '').strip()
        max_size = data.get('max_size', '').strip()
        is_highlighted = data.get('highlight_product')
        is_featured = data.get('is_featured')

        # Details fields
        details_description = data.get('details_description', '').strip()
        printing_embroidery = data.get('printing_embroidery', '').strip()
        textile_care = data.get('textile_care', '').strip()
        packaging = data.get('packaging', '').strip()
        counterparts = data.get('counterparts', '').strip()

        # Meta fields
        meta_title = data.get('meta_title', '').strip()
        meta_description = data.get('meta_description', '').strip()
        meta_keywords = data.get('meta_keywords', '').strip()
        meta_robots_index = data.get('meta_robots_index', 'index').strip()
        meta_robots_follow = data.get('meta_robots_follow', 'follow').strip()
        meta_canonical = data.get('meta_canonical', '').strip()
        og_title = data.get('og_title', '').strip()
        og_description = data.get('og_description', '').strip()
        og_url = data.get('og_url', '').strip()
        og_type = data.get('og_type', 'product').strip()
        twitter_card = data.get('twitter_card', 'summary_large_image').strip()
        twitter_title = data.get('twitter_title', '').strip()
        twitter_description = data.get('twitter_description', '').strip()

        # Image tokens
        main_image_token = data.get('main_image_token', '').strip()
        meta_image_token = data.get('meta_image_token', '').strip()
        size_spec_token = data.get('size_spec_token', '').strip()
        other_images_tokens = data.get('other_images_tokens', '').strip().split(',') if data.get('other_images_tokens') else []
        certificate_images_tokens = data.get('certificate_images_tokens', '').strip().split(',') if data.get('certificate_images_tokens') else []

        # Update fields
        if product_name:
            product.product_name = product_name
        if product_code:
            product.product_code = product_code
        if product_line:
            product.productline_id = product_line
        if category:
            product.category_id = category
        if description:
            product.specifications = description
        if fit:
            product.fit_id = fit
        if gsm:
            product.gsm = gsm
        if gender:
            product.gender = gender
        if sustainability:
            product.sustainability_id = sustainability
        if min_size:
            product.min_size_id = min_size
        if max_size:
            product.max_size_id = max_size
        if is_highlighted is not None:
            product.is_highlighted = bool(is_highlighted)
        if is_featured is not None:
            product.is_featured = bool(is_featured)

        # --- Handle main image ---
        if main_image_token:
            img_obj = ImageByToken.objects.filter(token=main_image_token).first()
            if img_obj and img_obj.image_path:
                old_path = img_obj.image_path
                if old_path.startswith('/static/upload/'):
                    try:
                        parts = old_path.split('/')
                        year = parts[3]
                        month = parts[4]
                    except Exception:
                        now = datetime.now()
                        year = now.strftime('%Y')
                        month = now.strftime('%m')
                    filename = os.path.basename(old_path)
                    new_rel_path = f'/static/product/{year}/{month}/{filename}'
                    old_abs = os.path.join(settings.BASE_DIR, old_path.lstrip('/'))
                    new_abs = os.path.join(settings.BASE_DIR, new_rel_path.lstrip('/'))
                    os.makedirs(os.path.dirname(new_abs), exist_ok=True)
                    shutil.move(old_abs, new_abs)
                    product.product_image = new_rel_path
                else:
                    product.product_image = old_path
            else:
                product.product_image = main_image_token

        # --- Handle other images (multi) ---
        if other_images_tokens:
            other_images_paths = []
            for token in other_images_tokens:
                token = token.strip()
                if not token:
                    continue
                img_obj = ImageByToken.objects.filter(token=token).first()
                if img_obj and img_obj.image_path:
                    old_path = img_obj.image_path
                    if old_path.startswith('/static/upload/'):
                        try:
                            parts = old_path.split('/')
                            year = parts[3]
                            month = parts[4]
                        except Exception:
                            now = datetime.now()
                            year = now.strftime('%Y')
                            month = now.strftime('%m')
                        filename = os.path.basename(old_path)
                        new_rel_path = f'/static/product/{year}/{month}/{filename}'
                        old_abs = os.path.join(settings.BASE_DIR, old_path.lstrip('/'))
                        new_abs = os.path.join(settings.BASE_DIR, new_rel_path.lstrip('/'))
                        os.makedirs(os.path.dirname(new_abs), exist_ok=True)
                        shutil.move(old_abs, new_abs)
                        other_images_paths.append(new_rel_path)
                    else:
                        other_images_paths.append(old_path)
                else:
                    other_images_paths.append(token)
            product.product_images = other_images_paths

        # --- Handle meta image ---
        meta_image_path = None
        if meta_image_token:
            img_obj = ImageByToken.objects.filter(token=meta_image_token).first()
            if img_obj and img_obj.image_path:
                old_path = img_obj.image_path
                if old_path.startswith('/static/upload/'):
                    try:
                        parts = old_path.split('/')
                        year = parts[3]
                        month = parts[4]
                    except Exception:
                        now = datetime.now()
                        year = now.strftime('%Y')
                        month = now.strftime('%m')
                    filename = os.path.basename(old_path)
                    new_rel_path = f'/static/product/{year}/{month}/{filename}'
                    old_abs = os.path.join(settings.BASE_DIR, old_path.lstrip('/'))
                    new_abs = os.path.join(settings.BASE_DIR, new_rel_path.lstrip('/'))
                    os.makedirs(os.path.dirname(new_abs), exist_ok=True)
                    shutil.move(old_abs, new_abs)
                    meta_image_path = new_rel_path
                else:
                    meta_image_path = old_path
            else:
                meta_image_path = meta_image_token

        # --- Handle size spec image ---
        size_spec_path = None
        if size_spec_token:
            img_obj = ImageByToken.objects.filter(token=size_spec_token).first()
            if img_obj and img_obj.image_path:
                old_path = img_obj.image_path
                if old_path.startswith('/static/upload/'):
                    try:
                        parts = old_path.split('/')
                        year = parts[3]
                        month = parts[4]
                    except Exception:
                        now = datetime.now()
                        year = now.strftime('%Y')
                        month = now.strftime('%m')
                    filename = os.path.basename(old_path)
                    new_rel_path = f'/static/product/{year}/{month}/{filename}'
                    old_abs = os.path.join(settings.BASE_DIR, old_path.lstrip('/'))
                    new_abs = os.path.join(settings.BASE_DIR, new_rel_path.lstrip('/'))
                    os.makedirs(os.path.dirname(new_abs), exist_ok=True)
                    shutil.move(old_abs, new_abs)
                    size_spec_path = new_rel_path
                else:
                    size_spec_path = old_path
            else:
                size_spec_path = size_spec_token

        # --- Handle certificate images (multi) ---
        # (Similar logic if you store these in a field/model)

        # Save product
        product.save()

        # --- Update ProductDetails ---
        details = ProductDetails.objects.filter(product=product).first()
        if not details:
            details = ProductDetails(product=product)
        if details_description:
            details.product_details = details_description
        if printing_embroidery:
            details.printing_options = printing_embroidery
        if textile_care:
            details.textile_care = textile_care
        if packaging:
            details.packaging = packaging
        if counterparts:
            details.counterparts = counterparts
        if size_spec_path:
            details.sizeSpecificationImage = size_spec_path
        details.save()

        # --- Update ProductMeta ---
        meta = ProductMeta.objects.filter(product=product).first()
        if not meta:
            meta = ProductMeta(product=product)
        if meta_title:
            meta.meta_title = meta_title
        if meta_description:
            meta.meta_description = meta_description
        if meta_keywords:
            meta.meta_keywords = meta_keywords
        if meta_robots_index:
            meta.meta_robots_index = meta_robots_index
        if meta_robots_follow:
            meta.meta_robots_follow = meta_robots_follow
        if meta_canonical:
            meta.meta_canonical = meta_canonical
        if meta_image_path:
            meta.meta_image = meta_image_path
        if og_title:
            meta.og_title = og_title
        if og_description:
            meta.og_description = og_description
        if og_url:
            meta.og_url = og_url
        if og_type:
            meta.og_type = og_type
        if twitter_card:
            meta.twitter_card = twitter_card
        if twitter_title:
            meta.twitter_title = twitter_title
        if twitter_description:
            meta.twitter_description = twitter_description
        meta.save()

        return JsonResponse({"status": "success", "message": "Product updated"})
    except Exception as e:
        return JsonResponse({"status": "error", "message": str(e)})

@csrf_exempt
def products_delete(request):
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'message': 'POST required'})
    try:
        data = request.POST if request.POST else json.loads(request.body.decode())
        product_id = data.get('id')
        if not product_id:
            return JsonResponse({'status': 'error', 'message': 'Product ID required'})
        product = Products.objects.filter(id=product_id).first()
        if not product:
            return JsonResponse({'status': 'error', 'message': 'Product not found'})
        product.delete()
        return JsonResponse({'status': 'success', 'message': 'Product deleted'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})

def sanitize_filename(filename):
    # Only allow English letters, numbers, hyphens, underscores, and dot (for extension)
    filename = re.sub(r'[^A-Za-z0-9._-]', '', filename)
    return filename

@csrf_exempt
@require_POST
def products_image_add(request):
    # Session check
    user_id = request.session.get('user_id')
    user_type = request.session.get('user_type')
    if not user_id or not user_type or user_type not in [1, 2]:
        return JsonResponse({'status': 'error', 'message': 'Authentication required.'}, status=401)
    file = request.FILES.get('file')
    field = request.POST.get('field', 'other')
    if not file:
        return JsonResponse({'status': 'error', 'message': 'No file uploaded.'}, status=400)
    now = timezone.now()
    day_of_year = now.timetuple().tm_yday
    upload_dir = os.path.join(settings.BASE_DIR, 'static', 'upload', str(now.year), f"{now.month:02d}")
    os.makedirs(upload_dir, exist_ok=True)
    original_name = file.name
    sanitized_name = sanitize_filename(original_name)
    base, ext = os.path.splitext(sanitized_name)
    # Add day-of-year to filename for uniqueness
    base = f"{base}-{day_of_year}"
    final_name = f"{base}{ext}"
    counter = 1
    while os.path.exists(os.path.join(upload_dir, final_name)):
        final_name = f"{base}-{counter}{ext}"
        counter += 1
    file_path = os.path.join(upload_dir, final_name)
    with open(file_path, 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)
    # Save relative path for DB/static
    rel_path = f"upload/{now.year}/{now.month:02d}/{final_name}"
    url = f"/static/{rel_path}"
    # Generate unique token and save to ImageByToken
    token = uuid.uuid4().hex
    image_token_obj = ImageByToken.objects.create(token=token, image_path=url)
    return JsonResponse({'status': 'success', 'token': token})

@csrf_exempt
@require_POST
def products_image_delete(request):
    # Session check
    user_id = request.session.get('user_id')
    user_type = request.session.get('user_type')
    if not user_id or not user_type or user_type not in [1, 2]:
        return JsonResponse({'status': 'error', 'message': 'Authentication required.'}, status=401)
    token = request.POST.get('token')
    if not token:
        return JsonResponse({'status': 'error', 'message': 'No token provided.'}, status=400)
    try:
        image_token_obj = ImageByToken.objects.get(token=token)
    except ImageByToken.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Token not found.'}, status=404)
    # Remove leading slash if present
    path = image_token_obj.image_path
    rel_path = path.lstrip('/')
    abs_path = os.path.join(settings.BASE_DIR, rel_path)
    if os.path.exists(abs_path):
        os.remove(abs_path)
    image_token_obj.delete()
    return JsonResponse({'status': 'success', 'message': 'Image deleted.'})

@csrf_exempt
def products_details_get(request):
    """
    Get full product info by id (query param: id)
    """
    product_id = request.GET.get('id')
    if not product_id:
        return JsonResponse({'status': 'error', 'message': 'Product ID required'}, status=400)
    prod = Products.objects.filter(id=product_id).first()
    if not prod:
        return JsonResponse({'status': 'error', 'message': 'Product not found'}, status=404)
    # Basic info
    productline_name = prod.productline_obj.name if prod.productline_obj else ''
    category_name = prod.category_obj.name if prod.category_obj else ''
    fit_name = prod.fit_obj.name if prod.fit_obj else ''
    gender_display = dict(Products.GENDER_CHOICES).get(prod.gender, '')
    # Details
    details = ProductDetails.objects.filter(product=prod).first()
    meta = ProductMeta.objects.filter(product=prod).first()
    # Colors (many-to-many)
    colors = []
    if hasattr(prod, 'colors_obj'):
        colors = [{'id': c.id, 'name': c.name, 'value': c.value} for c in prod.colors_obj.all()]
    # Compose response
    data = {
        'id': prod.id,
        'product_name': prod.product_name,
        'product_code': prod.product_code,
        'productline_id': prod.productline_id,
        'productline_name': productline_name,
        'category_id': prod.category_id,
        'category_name': category_name,
        'fit_id': prod.fit_id,
        'fit_name': fit_name,
        'gsm': prod.gsm,
        'gender': prod.gender,
        'gender_display': gender_display,
        'is_highlighted': prod.is_highlighted,
        'is_featured': prod.is_featured,
        'is_active': prod.is_active,
        'specifications': prod.specifications,
        'product_image': prod.product_image,
        'product_image_alttext': prod.product_image_alttext,
        'product_images': prod.product_images,
        'sustainability_id': prod.sustainability_id,
        'min_size_id': prod.min_size_id,
        'max_size_id': prod.max_size_id,
        'created_at': prod.created_at,
        'updated_at': prod.updated_at,
        'colors': colors,
        # Details
        'details': {
            'product_details': details.product_details if details else '',
            'printing_options': details.printing_options if details else '',
            'textile_care': details.textile_care if details else '',
            'packaging': details.packaging if details else '',
            'counterparts': details.counterparts if details else '',
            'sizeSpecificationImage': details.sizeSpecificationImage if details else '',
        },
        # Meta
        'meta': {
            'meta_title': meta.meta_title if meta else '',
            'meta_description': meta.meta_description if meta else '',
            'meta_keywords': meta.meta_keywords if meta else '',
            'meta_robots_index': meta.meta_robots_index if meta else '',
            'meta_robots_follow': meta.meta_robots_follow if meta else '',
            'meta_canonical': meta.meta_canonical if meta else '',
            'meta_image': meta.meta_image if meta else '',
            'og_title': meta.og_title if meta else '',
            'og_description': meta.og_description if meta else '',
            'og_url': meta.og_url if meta else '',
            'og_type': meta.og_type if meta else '',
            'twitter_card': meta.twitter_card if meta else '',
            'twitter_title': meta.twitter_title if meta else '',
            'twitter_description': meta.twitter_description if meta else '',
            'meta_social': meta.meta_social if meta else {},
        }
    }
    return JsonResponse({'status': 'success', 'product': data})


