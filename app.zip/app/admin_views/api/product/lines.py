from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from app.models.product.lines import ProductLine
import json

def serialize_line(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "desc": obj.description,
        "status": "Active" if obj.status == "1" else "Inactive"
    }

def paginate_queryset(qs, page, page_size):
    total = qs.count()
    start = (page - 1) * page_size
    end = start + page_size
    results = list(qs[start:end])
    return results, total

@csrf_exempt
def products_line_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    qs = ProductLine.objects.all().order_by('-id')
    results, total = paginate_queryset(qs, page, page_size)
    data = [serialize_line(obj) for obj in results]
    return JsonResponse({
        "results": data,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size
    })

@csrf_exempt
def products_line_pagination(request):
    return products_line_get(request)

@csrf_exempt
def products_line_add(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            name = data.get("name", "").strip()
            desc = data.get("desc", "").strip()
            if not name:
                return JsonResponse({"status": "error", "message": "Line name is required."}, status=400)
            line = ProductLine.objects.create(name=name, description=desc, status="1")
            return JsonResponse({"status": "success", "message": "Line added.", "id": line.id})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
    return JsonResponse({"status": "error", "message": "Invalid request method."}, status=405)

@csrf_exempt
def products_line_edit(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            line_id = data.get("id")
            name = data.get("name", "").strip()
            desc = data.get("desc", "").strip()
            if not line_id or not name:
                return JsonResponse({"status": "error", "message": "ID and name are required."}, status=400)
            try:
                line = ProductLine.objects.get(id=line_id)
            except ProductLine.DoesNotExist:
                return JsonResponse({"status": "error", "message": "Line not found."}, status=404)
            line.name = name
            line.description = desc
            line.save()
            return JsonResponse({"status": "success", "message": "Line updated."})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
    return JsonResponse({"status": "error", "message": "Invalid request method."}, status=405)

@csrf_exempt
def products_line_delete(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            line_id = data.get("id")
            if not line_id:
                return JsonResponse({"status": "error", "message": "ID is required."}, status=400)
            try:
                line = ProductLine.objects.get(id=line_id)
            except ProductLine.DoesNotExist:
                return JsonResponse({"status": "error", "message": "Line not found."}, status=404)
            line.delete()
            return JsonResponse({"status": "success", "message": "Line deleted."})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
    return JsonResponse({"status": "error", "message": "Invalid request method."}, status=405)
