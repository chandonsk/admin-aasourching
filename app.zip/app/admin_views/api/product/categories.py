from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from app.models.product.categories import ProductCategory
from app.models.product.lines import ProductLine
import json

def serialize_category(obj):
    return {
        "id": obj.id,
        "name": obj.name,
        "desc": obj.description,
        "status": "Active" if obj.status == "1" else "Inactive",
        "product_line": obj.product_line.id if obj.product_line else None,
        "product_line_name": obj.product_line.name if obj.product_line else "",
    }

def paginate_queryset(qs, page, page_size):
    total = qs.count()
    start = (page - 1) * page_size
    end = start + page_size
    results = list(qs[start:end])
    return results, total

@csrf_exempt
def products_category_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    product_line_id = request.GET.get('product_line')
    qs = ProductCategory.objects.all().order_by('-id')
    if product_line_id:
        qs = qs.filter(product_line_id=product_line_id)
    results, total = paginate_queryset(qs, page, page_size)
    data = [serialize_category(obj) for obj in results]
    return JsonResponse({
        "results": data,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size
    })

@csrf_exempt
def products_category_pagination(request):
    return products_category_get(request)

@csrf_exempt
def products_category_add(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            name = data.get("name", "").strip()
            desc = data.get("desc", "").strip()
            product_line_id = data.get("product_line")
            if not name or not product_line_id:
                return JsonResponse({"status": "error", "message": "Name and product line are required."}, status=400)
            try:
                product_line = ProductLine.objects.get(id=product_line_id)
            except ProductLine.DoesNotExist:
                return JsonResponse({"status": "error", "message": "Product line not found."}, status=404)
            # Check for duplicate name within the same product_line
            if ProductCategory.objects.filter(product_line=product_line, name=name).exists():
                return JsonResponse({"status": "error", "message": "This category name already exists for the selected product line."}, status=400)
            cat = ProductCategory.objects.create(
                name=name,
                description=desc,
                product_line=product_line,
                status="1"
            )
            return JsonResponse({"status": "success", "message": "Category added.", "id": cat.id})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
    return JsonResponse({"status": "error", "message": "Invalid request method."}, status=405)

@csrf_exempt
def products_category_edit(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            cat_id = data.get("id")
            name = data.get("name", "").strip()
            desc = data.get("desc", "").strip()
            product_line_id = data.get("product_line")
            if not cat_id or not name or not product_line_id:
                return JsonResponse({"status": "error", "message": "ID, name, and product line are required."}, status=400)
            try:
                cat = ProductCategory.objects.get(id=cat_id)
                product_line = ProductLine.objects.get(id=product_line_id)
            except (ProductCategory.DoesNotExist, ProductLine.DoesNotExist):
                return JsonResponse({"status": "error", "message": "Category or product line not found."}, status=404)
            # Check for duplicate name within the same product_line (excluding self)
            if ProductCategory.objects.filter(product_line=product_line, name=name).exclude(id=cat_id).exists():
                return JsonResponse({"status": "error", "message": "This category name already exists for the selected product line."}, status=400)
            cat.name = name
            cat.description = desc
            cat.product_line = product_line
            cat.save()
            return JsonResponse({"status": "success", "message": "Category updated."})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
    return JsonResponse({"status": "error", "message": "Invalid request method."}, status=405)

@csrf_exempt
def products_category_delete(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            cat_id = data.get("id")
            if not cat_id:
                return JsonResponse({"status": "error", "message": "ID is required."}, status=400)
            try:
                cat = ProductCategory.objects.get(id=cat_id)
            except ProductCategory.DoesNotExist:
                return JsonResponse({"status": "error", "message": "Category not found."}, status=404)
            cat.delete()
            return JsonResponse({"status": "success", "message": "Category deleted."})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
    return JsonResponse({"status": "error", "message": "Invalid request method."}, status=405)

@csrf_exempt
def products_category_lines(request):
    # Returns all product lines for populating the selector
    lines = ProductLine.objects.all().order_by('name')
    data = [{"id": l.id, "name": l.name} for l in lines]
    return JsonResponse({"results": data})

@csrf_exempt
def products_category_simple_get(request):
    qs = ProductCategory.objects.all().select_related('line')
    data = []
    for cat in qs:
        data.append({
            "id": cat.id,
            "name": cat.name,
            "line_name": getattr(cat.line, "name", "") if hasattr(cat, "line") else ""
        })
    return JsonResponse({"results": data})
