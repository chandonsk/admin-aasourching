from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from app.models.user.admin import Admin
from app.models.user.moderator import Moderator
from app.models.user.support import Support
from app.models.user.deliveryman import DeliveryMan
from app.models.user.company import Company
from app.models.user.customer import Customer
from app.models.user.guest import Guest
from django.core.paginator import Paginator
import json
from django.views.decorators.http import require_http_methods

@csrf_exempt
def users_requests_get(request):
    return JsonResponse({"status": "success", "message": "users_requests_get placeholder"})

@csrf_exempt
def users_requests_pagination(request):
    return JsonResponse({"status": "success", "message": "users_requests_pagination placeholder"})

@csrf_exempt
def users_requests_add(request):
    return JsonResponse({"status": "success", "message": "users_requests_add placeholder"})

@csrf_exempt
def users_admin_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    queryset = Admin.objects.all().order_by('-id')
    paginator = Paginator(queryset, page_size)
    page_obj = paginator.get_page(page)
    results = []
    for user in page_obj.object_list:
        results.append({
            "id": user.id,
            "full_name": user.full_name,
            "email": user.email,
            "phone_number": user.phone_number,
            "date_of_birth": user.date_of_birth.isoformat() if user.date_of_birth else "",
            "status": "Active" if user.is_active else "Inactive",
            "profile_image": user.profile_image.url if user.profile_image else "",
        })
    return JsonResponse({
        "status": "success",
        "results": results,
        "page": page,
        "page_size": page_size,
        "total": paginator.count,
        "total_pages": paginator.num_pages,
    })

@csrf_exempt
def users_admin_pagination(request):
    return users_admin_get(request)

@csrf_exempt
def users_admin_add(request):
    return JsonResponse({"status": "success", "message": "users_admin_add placeholder"})

@csrf_exempt
def users_moderator_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    queryset = Moderator.objects.all().order_by('-id')
    paginator = Paginator(queryset, page_size)
    page_obj = paginator.get_page(page)
    results = []
    for user in page_obj.object_list:
        # Map status int to string
        if hasattr(user, "status"):
            if user.status == 1:
                status_str = "Active"
            elif user.status == 0:
                status_str = "Inactive"
            elif user.status == -1:
                status_str = "Banned"
            else:
                status_str = "Inactive"
        else:
            status_str = "Active" if user.is_active else "Inactive"
        results.append({
            "id": user.id,
            "full_name": user.full_name,
            "email": user.email,
            "phone_number": user.phone_number,
            "assigned_area": getattr(user, "assigned_area", "") or "",
            "status": status_str,
            "profile_image": user.profile_image.url if user.profile_image else "",
        })
    return JsonResponse({
        "status": "success",
        "results": results,
        "page": page,
        "page_size": page_size,
        "total": paginator.count,
        "total_pages": paginator.num_pages,
    })

@csrf_exempt
def users_moderator_pagination(request):
    return users_moderator_get(request)

@csrf_exempt
def users_moderator_add(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            full_name = data.get("full_name", "")
            email = data.get("email", "")
            phone_number = data.get("phone_number", "")
            password = data.get("password", "")
            # Additional fields from Users model
            country_id = data.get("country_id")
            date_of_birth = data.get("date_of_birth")
            gender = data.get("gender")
            national_id = data.get("national_id")
            referral_code = data.get("referral_code")
            company_name = data.get("company_name")
            company_address = data.get("company_address")
            user_name = data.get("user_name")
            is_premium_member = data.get("is_premium_member", False)
            newsletter_subscribed = data.get("newsletter_subscribed", False)
            preferred_language = data.get("preferred_language", "en")

            # Required fields check
            if not full_name or not email or not password or not country_id:
                return JsonResponse({"status": "error", "message": "Full name, email, password, and country are required."})

            # Check if email already exists
            if Moderator.objects.filter(email=email).exists():
                return JsonResponse({"status": "error", "message": "Email already exists."})

            moderator = Moderator.objects.create(
                full_name=full_name,
                email=email,
                phone_number=phone_number,
                password=password,
                user_type=2,
                is_active=True,
                country_id=country_id,
                date_of_birth=date_of_birth if date_of_birth else None,
                gender=gender if gender else None,
                national_id=national_id if national_id else None,
                referral_code=referral_code if referral_code else None,
                company_name=company_name if company_name else None,
                company_address=company_address if company_address else None,
                user_name=user_name if user_name else None,
                is_premium_member=bool(is_premium_member),
                newsletter_subscribed=bool(newsletter_subscribed),
                preferred_language=preferred_language if preferred_language else "en",
            )

            return JsonResponse({"status": "success", "message": "Moderator added successfully."})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
    return JsonResponse({"status": "error", "message": "Invalid request method."})

@csrf_exempt
def users_support_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    queryset = Support.objects.all().order_by('-id')
    paginator = Paginator(queryset, page_size)
    page_obj = paginator.get_page(page)
    results = []
    for user in page_obj.object_list:
        results.append({
            "id": user.id,
            "full_name": user.full_name,
            "email": user.email,
            "phone_number": user.phone_number,
            "shift": getattr(user, "shift", "") or "",
            "status": "Active" if user.is_active else "Inactive",
            "profile_image": user.profile_image.url if user.profile_image else "",
        })
    return JsonResponse({
        "status": "success",
        "results": results,
        "page": page,
        "page_size": page_size,
        "total": paginator.count,
        "total_pages": paginator.num_pages,
    })

@csrf_exempt
def users_support_pagination(request):
    return users_support_get(request)

@csrf_exempt
def users_support_add(request):
    return JsonResponse({"status": "success", "message": "users_support_add placeholder"})

@csrf_exempt
def users_deliveryman_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    queryset = DeliveryMan.objects.all().order_by('-id')
    paginator = Paginator(queryset, page_size)
    page_obj = paginator.get_page(page)
    results = []
    for user in page_obj.object_list:
        results.append({
            "id": user.id,
            "full_name": user.full_name,
            "email": user.email,
            "phone_number": user.phone_number,
            "area": getattr(user, "area", "") or "",
            "status": "Active" if user.is_active else "Inactive",
            "profile_image": user.profile_image.url if user.profile_image else "",
        })
    return JsonResponse({
        "status": "success",
        "results": results,
        "page": page,
        "page_size": page_size,
        "total": paginator.count,
        "total_pages": paginator.num_pages,
    })

@csrf_exempt
def users_deliveryman_pagination(request):
    return users_deliveryman_get(request)

@csrf_exempt
def users_deliveryman_add(request):
    return JsonResponse({"status": "success", "message": "users_deliveryman_add placeholder"})

@csrf_exempt
def users_company_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    queryset = Company.objects.all().order_by('-id')
    paginator = Paginator(queryset, page_size)
    page_obj = paginator.get_page(page)
    results = []
    for user in page_obj.object_list:
        results.append({
            "id": user.id,
            "full_name": user.full_name,
            "email": user.email,
            "phone_number": user.phone_number,
            "company_name": user.company_name or "",
            "status": "Active" if user.is_active else "Inactive",
            "profile_image": user.profile_image.url if user.profile_image else "",
        })
    return JsonResponse({
        "status": "success",
        "results": results,
        "page": page,
        "page_size": page_size,
        "total": paginator.count,
        "total_pages": paginator.num_pages,
    })

@csrf_exempt
def users_company_pagination(request):
    return users_company_get(request)

@csrf_exempt
def users_company_add(request):
    return JsonResponse({"status": "success", "message": "users_company_add placeholder"})

@csrf_exempt
def users_customer_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    queryset = Customer.objects.all().order_by('-id')
    paginator = Paginator(queryset, page_size)
    page_obj = paginator.get_page(page)
    results = []
    for user in page_obj.object_list:
        results.append({
            "id": user.id,
            "full_name": user.full_name,
            "email": user.email,
            "phone_number": user.phone_number,
            "address": user.company_address or "",
            "status": "Active" if user.is_active else "Inactive",
            "profile_image": user.profile_image.url if user.profile_image else "",
        })
    return JsonResponse({
        "status": "success",
        "results": results,
        "page": page,
        "page_size": page_size,
        "total": paginator.count,
        "total_pages": paginator.num_pages,
    })

@csrf_exempt
def users_customer_pagination(request):
    return users_customer_get(request)

@csrf_exempt
def users_customer_add(request):
    return JsonResponse({"status": "success", "message": "users_customer_add placeholder"})

@csrf_exempt
def users_guest_get(request):
    page = int(request.GET.get('page', 1))
    page_size = int(request.GET.get('page_size', 10))
    queryset = Guest.objects.all().order_by('-id')
    paginator = Paginator(queryset, page_size)
    page_obj = paginator.get_page(page)
    results = []
    for user in page_obj.object_list:
        results.append({
            "id": user.id,
            "full_name": user.full_name,
            "email": user.email,
            "phone_number": user.phone_number,
            "visit_date": getattr(user, "visit_date", "") or "",
            "status": "Active" if user.is_active else "Inactive",
            "profile_image": user.profile_image.url if user.profile_image else "",
        })
    return JsonResponse({
        "status": "success",
        "results": results,
        "page": page,
        "page_size": page_size,
        "total": paginator.count,
        "total_pages": paginator.num_pages,
    })

@csrf_exempt
def users_guest_pagination(request):
    return users_guest_get(request)

@csrf_exempt
def users_guest_add(request):
    return JsonResponse({"status": "success", "message": "users_guest_add placeholder"})

@csrf_exempt
def users_usercontrol_get(request):
    return JsonResponse({"status": "success", "message": "users_usercontrol_get placeholder"})

@csrf_exempt
def users_usercontrol_pagination(request):
    return JsonResponse({"status": "success", "message": "users_usercontrol_pagination placeholder"})

@csrf_exempt
def users_usercontrol_add(request):
    return JsonResponse({"status": "success", "message": "users_usercontrol_add placeholder"})

@csrf_exempt
def users_managepermissions_get(request):
    return JsonResponse({"status": "success", "message": "users_managepermissions_get placeholder"})

@csrf_exempt
def users_managepermissions_pagination(request):
    return JsonResponse({"status": "success", "message": "users_managepermissions_pagination placeholder"})

@csrf_exempt
def users_managepermissions_add(request):
    return JsonResponse({"status": "success", "message": "users_managepermissions_add placeholder"})

@csrf_exempt
def users_requests_edit(request):
    return JsonResponse({"status": "success", "message": "users_requests_edit placeholder"})

@csrf_exempt
def users_requests_delete(request):
    return JsonResponse({"status": "success", "message": "users_requests_delete placeholder"})

@csrf_exempt
def users_admin_edit(request):
    return JsonResponse({"status": "success", "message": "users_admin_edit placeholder"})

@csrf_exempt
def users_admin_delete(request):
    return JsonResponse({"status": "success", "message": "users_admin_delete placeholder"})

@csrf_exempt
def users_moderator_edit(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            moderator_id = data.get("id")
            new_status = data.get("status")
            if moderator_id is None or new_status is None:
                return JsonResponse({"status": "error", "message": "Moderator ID and status are required."})
            try:
                moderator = Moderator.objects.get(id=moderator_id)
            except Moderator.DoesNotExist:
                return JsonResponse({"status": "error", "message": "Moderator not found."})
            # Update status field (not is_active)
            moderator.status = int(new_status)
            # Optionally, update is_active for compatibility
            moderator.is_active = True if int(new_status) == 1 else False
            moderator.save()
            return JsonResponse({"status": "success", "message": "Moderator status updated."})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
    return JsonResponse({"status": "error", "message": "Invalid request method."})

@csrf_exempt
def users_moderator_delete(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode())
            moderator_id = data.get("id")
            if moderator_id is None:
                return JsonResponse({"status": "error", "message": "Moderator ID is required."})
            try:
                moderator = Moderator.objects.get(id=moderator_id)
            except Moderator.DoesNotExist:
                return JsonResponse({"status": "error", "message": "Moderator not found."})
            # Set status to -1 (deleted) and deactivate
            moderator.status = -1
            moderator.is_active = False
            moderator.save()
            return JsonResponse({"status": "success", "message": "Moderator deleted."})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
    return JsonResponse({"status": "error", "message": "Invalid request method."})

@csrf_exempt
def users_support_edit(request):
    return JsonResponse({"status": "success", "message": "users_support_edit placeholder"})

@csrf_exempt
def users_support_delete(request):
    return JsonResponse({"status": "success", "message": "users_support_delete placeholder"})

@csrf_exempt
def users_deliveryman_edit(request):
    return JsonResponse({"status": "success", "message": "users_deliveryman_edit placeholder"})

@csrf_exempt
def users_deliveryman_delete(request):
    return JsonResponse({"status": "success", "message": "users_deliveryman_delete placeholder"})

@csrf_exempt
def users_company_edit(request):
    return JsonResponse({"status": "success", "message": "users_company_edit placeholder"})

@csrf_exempt
def users_company_delete(request):
    return JsonResponse({"status": "success", "message": "users_company_delete placeholder"})

@csrf_exempt
def users_customer_edit(request):
    return JsonResponse({"status": "success", "message": "users_customer_edit placeholder"})

@csrf_exempt
def users_customer_delete(request):
    return JsonResponse({"status": "success", "message": "users_customer_delete placeholder"})

@csrf_exempt
def users_guest_edit(request):
    return JsonResponse({"status": "success", "message": "users_guest_edit placeholder"})

@csrf_exempt
def users_guest_delete(request):
    return JsonResponse({"status": "success", "message": "users_guest_delete placeholder"})

@csrf_exempt
def users_usercontrol_edit(request):
    return JsonResponse({"status": "success", "message": "users_usercontrol_edit placeholder"})

@csrf_exempt
def users_usercontrol_delete(request):
    return JsonResponse({"status": "success", "message": "users_usercontrol_delete placeholder"})

@csrf_exempt
def users_managepermissions_edit(request):
    return JsonResponse({"status": "success", "message": "users_managepermissions_edit placeholder"})

@csrf_exempt
def users_managepermissions_delete(request):
    return JsonResponse({"status": "success", "message": "users_managepermissions_delete placeholder"})
    return JsonResponse({"status": "success", "message": "users_managepermissions_edit placeholder"})

@csrf_exempt
def users_managepermissions_delete(request):
    return JsonResponse({"status": "success", "message": "users_managepermissions_delete placeholder"})
