from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import os
from django.conf import settings
from django.views.decorators.http import require_POST
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from django.utils import timezone
import re
from app.models.product.products import ImageByToken
from app.models.upload import ImageByToken
from django.db import transaction
import uuid





def sanitize_filename(filename):
    # Only allow English letters, numbers, hyphens, underscores, and dot (for extension)
    filename = re.sub(r'[^A-Za-z0-9._-]', '', filename)
    return filename



@csrf_exempt
@require_POST
def image_add(request):
    # Session check
    user_id = request.session.get('user_id')
    user_type = request.session.get('user_type')
    if not user_id or not user_type or user_type not in [1, 2]:
        return JsonResponse({'status': 'error', 'message': 'Authentication required.'}, status=401)
    file = request.FILES.get('file')
    field = request.POST.get('field', 'other')
    if not file:
        return JsonResponse({'status': 'error', 'message': 'No file uploaded.'}, status=400)
    now = timezone.now()
    day_of_year = now.timetuple().tm_yday
    upload_dir = os.path.join(settings.BASE_DIR, 'static', 'upload', str(now.year), f"{now.month:02d}")
    os.makedirs(upload_dir, exist_ok=True)
    original_name = file.name
    sanitized_name = sanitize_filename(original_name)
    base, ext = os.path.splitext(sanitized_name)
    # Add day-of-year to filename for uniqueness
    base = f"{base}-{day_of_year}"
    final_name = f"{base}{ext}"
    counter = 1
    while os.path.exists(os.path.join(upload_dir, final_name)):
        final_name = f"{base}-{counter}{ext}"
        counter += 1
    file_path = os.path.join(upload_dir, final_name)
    with open(file_path, 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)
    # Save relative path for DB/static
    rel_path = f"upload/{now.year}/{now.month:02d}/{final_name}"
    url = f"/static/{rel_path}"
    # Generate unique token and save to ImageByToken
    token = uuid.uuid4().hex
    image_token_obj = ImageByToken.objects.create(token=token, image_path=url)
    return JsonResponse({'status': 'success', 'token': token})

@csrf_exempt
@require_POST
def image_delete(request):
    # Session check
    user_id = request.session.get('user_id')
    user_type = request.session.get('user_type')
    if not user_id or not user_type or user_type not in [1, 2]:
        return JsonResponse({'status': 'error', 'message': 'Authentication required.'}, status=401)
    token = request.POST.get('token')
    if not token:
        return JsonResponse({'status': 'error', 'message': 'No token provided.'}, status=400)
    try:
        image_token_obj = ImageByToken.objects.get(token=token)
    except ImageByToken.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Token not found.'}, status=404)
    # Remove leading slash if present
    path = image_token_obj.image_path
    rel_path = path.lstrip('/')
    abs_path = os.path.join(settings.BASE_DIR, rel_path)
    if os.path.exists(abs_path):
        os.remove(abs_path)
    image_token_obj.delete()
    return JsonResponse({'status': 'success', 'message': 'Image deleted.'})