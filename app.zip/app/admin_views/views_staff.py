from django.shortcuts import render

def staff_allstaff(request):
    return render(request, 'mainadmin/staff/allstaff.html')
def staff_roles(request):
    return render(request, 'mainadmin/staff/roles.html')
def staff_permissions(request):
    return render(request, 'mainadmin/staff/permissions.html')
def staff_activity(request):
    return render(request, 'mainadmin/staff/activity.html')

__all__ = [
    'staff_allstaff', 'staff_roles', 'staff_permissions', 'staff_activity'
]
