from django.shortcuts import render

def message(request):
    return render(request, 'mainadmin/message.html')

__all__ = ['message']
