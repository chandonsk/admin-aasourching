from django.urls import path, include
from .api import mainadmin

# Product imports
from .api.upload import (
    image_add, image_delete,
)
from .api.product.products import (
    products_get, products_pagination, products_add, products_edit, products_delete,
    products_image_add, products_image_delete,
    products_details_get, products_slug_check,
)
from .api.product.brand import (
    products_brand_get, products_brand_pagination, products_brand_add, products_brand_edit, products_brand_delete,
)
from .api.product.categories import (
    products_category_get, products_category_pagination, products_category_add, products_category_edit, products_category_delete,
)
from .api.product.lines import (
    products_line_get, products_line_pagination, products_line_add, products_line_edit, products_line_delete,
)
from .api.product.colors import (
    products_colors_get, products_colors_pagination, products_colors_add, products_colors_edit, products_colors_delete,
)
from .api.product.sustainability import (
    products_sustainability_get, products_sustainability_pagination, products_sustainability_add, products_sustainability_edit, products_sustainability_delete,
)
from .api.product.fit import (
    products_fit_get, products_fit_pagination, products_fit_add, products_fit_edit, products_fit_delete,
)
from .api.product.size_range import (
    products_size_range_get, products_size_range_pagination, products_size_range_add, products_size_range_edit, products_size_range_delete,
)
from .api.product.attributes import (
    products_attributes_get, products_attributes_pagination, products_attributes_add, products_attributes_edit, products_attributes_delete,
)
from .api.product.reviews import (
    products_reviews_get, products_reviews_pagination, products_reviews_add, products_reviews_edit, products_reviews_delete,
)

# Staff imports
from .api.staff import (
    staff_get, staff_pagination, staff_add, staff_edit, staff_delete,
    staff_roles_get, staff_roles_pagination, staff_roles_add, staff_roles_edit, staff_roles_delete,
    staff_permissions_get, staff_permissions_pagination, staff_permissions_add, staff_permissions_edit, staff_permissions_delete,
    staff_activity_get, staff_activity_pagination, staff_activity_add, staff_activity_edit, staff_activity_delete,
)

# Order imports
from .api.order import (
    order_pending_get, order_pending_pagination, order_pending_add, order_pending_edit, order_pending_delete,
    order_processing_get, order_processing_pagination, order_processing_add, order_processing_edit, order_processing_delete,
    order_complete_get, order_complete_pagination, order_complete_add, order_complete_edit, order_complete_delete,
    order_get, order_pagination, order_add, order_edit, order_delete,
)

# Brandsclients
from .api.brandsclient import (
    brandsclients_get, brandsclients_pagination, brandsclients_add, brandsclients_edit, brandsclients_delete,
    brandsclients_avatar_upload,  
)

# Message
from .api.message import (
    message_get, message_pagination, message_add, message_edit, message_delete,
)

# Transactions
from .api.transactions import (
    transactions_get, transactions_pagination, transactions_add, transactions_edit, transactions_delete,
    transactions_incomming_get, transactions_incomming_pagination, transactions_incomming_add, transactions_incomming_edit, transactions_incomming_delete,
    transactions_outgoging_get, transactions_outgoging_pagination, transactions_outgoging_add, transactions_outgoging_edit, transactions_outgoging_delete,
)

# Marketing
from .api.marketing import (
    marketing_coupons_get, marketing_coupons_pagination, marketing_coupons_add, marketing_coupons_edit, marketing_coupons_delete,
    marketing_campaigns_get, marketing_campaigns_pagination, marketing_campaigns_add, marketing_campaigns_edit, marketing_campaigns_delete,
    marketing_banners_get, marketing_banners_pagination, marketing_banners_add, marketing_banners_edit, marketing_banners_delete,
    marketing_newsletters_get, marketing_newsletters_pagination, marketing_newsletters_add, marketing_newsletters_edit, marketing_newsletters_delete,
)

# Reports
from .api.reports import (
    reports_sales_get, reports_sales_pagination, reports_sales_add, reports_sales_edit, reports_sales_delete,
    reports_customers_get, reports_customers_pagination, reports_customers_add, reports_customers_edit, reports_customers_delete,
    reports_products_get, reports_products_pagination, reports_products_add, reports_products_edit, reports_products_delete,
    reports_stock_get, reports_stock_pagination, reports_stock_add, reports_stock_edit, reports_stock_delete,
    reports_finance_get, reports_finance_pagination, reports_finance_add, reports_finance_edit, reports_finance_delete,
)

# CMS Blogs
from .api.cms.blogs import (
    blogs_get, blogs_pagination, blogs_add, blogs_edit, blogs_delete,
    blogs_category_get, blogs_category_pagination, blogs_category_add, blogs_category_edit, blogs_category_delete,
    blogs_detail,
)

# CMS Pages
from .api.cms.pages import (
    cms_pages_get, cms_pages_pagination, cms_pages_add, cms_pages_edit, cms_pages_delete,
    cms_category_get, cms_category_pagination, cms_category_add, cms_category_edit, cms_category_delete,
)

# CMS Menus
from .api.cms.menus import (
    cms_menus_get, cms_menus_pagination, cms_menus_add, cms_menus_edit, cms_menus_delete,
    menu_category_get, menu_category_pagination, menu_category_add, menu_category_edit, menu_category_delete,
)

# CMS Media
from .api.cms.media import (
    cms_media_get, cms_media_pagination, cms_media_add, cms_media_edit, cms_media_delete,
    media_category_get, media_category_pagination, media_category_add, media_category_edit, media_category_delete,
)

# User
from .api.user import (
    users_requests_get, users_requests_pagination, users_requests_add, users_requests_edit, users_requests_delete,
    users_admin_get, users_admin_pagination, users_admin_add, users_admin_edit, users_admin_delete,
    users_moderator_get, users_moderator_pagination, users_moderator_add, users_moderator_edit, users_moderator_delete,
    users_support_get, users_support_pagination, users_support_add, users_support_edit, users_support_delete,
    users_deliveryman_get, users_deliveryman_pagination, users_deliveryman_add, users_deliveryman_edit, users_deliveryman_delete,
    users_company_get, users_company_pagination, users_company_add, users_company_edit, users_company_delete,
    users_customer_get, users_customer_pagination, users_customer_add, users_customer_edit, users_customer_delete,
    users_guest_get, users_guest_pagination, users_guest_add, users_guest_edit, users_guest_delete,
    users_usercontrol_get, users_usercontrol_pagination, users_usercontrol_add, users_usercontrol_edit, users_usercontrol_delete,
    users_managepermissions_get, users_managepermissions_pagination, users_managepermissions_add, users_managepermissions_edit, users_managepermissions_delete,
)

app_name = 'mainadmin'


urlpatterns = [
    path('', mainadmin, name='mainadmin'),

    # Flat endpoints for all products submodules
    path('products/get', products_get, name='products_get'),
    path('products/pagination', products_pagination, name='products_pagination'),
    path('products/all/add', products_add, name='products_add'),
    path('products/edit', products_edit, name='products_edit'),
    path('products/delete', products_delete, name='products_delete'),
    path('products/details/get', products_details_get, name='products_details_get'),  

    path('products/brand/get', products_brand_get, name='products_brand_get'),
    path('products/brand/pagination', products_brand_pagination, name='products_brand_pagination'),
    path('products/brand/add', products_brand_add, name='products_brand_add'),
    path('products/brand/edit', products_brand_edit, name='products_brand_edit'),
    path('products/brand/delete', products_brand_delete, name='products_brand_delete'),

    path('products/slug/check', products_slug_check, name='products_slug_check'),

    path('products/category/get', products_category_get, name='products_category_get'),
    path('products/category/pagination', products_category_pagination, name='products_category_pagination'),
    path('products/category/add', products_category_add, name='products_category_add'),
    path('products/category/edit', products_category_edit, name='products_category_edit'),
    path('products/category/delete', products_category_delete, name='products_category_delete'),

    path('products/line/get', products_line_get, name='products_line_get'),
    path('products/line/pagination', products_line_pagination, name='products_line_pagination'),
    path('products/line/add', products_line_add, name='products_line_add'),
    path('products/line/edit', products_line_edit, name='products_line_edit'),
    path('products/line/delete', products_line_delete, name='products_line_delete'),

    path('products/colors/get', products_colors_get, name='products_colors_get'),
    path('products/colors/pagination', products_colors_pagination, name='products_colors_pagination'),
    path('products/colors/add', products_colors_add, name='products_colors_add'),
    path('products/colors/edit', products_colors_edit, name='products_colors_edit'),
    path('products/colors/delete', products_colors_delete, name='products_colors_delete'),

    path('products/sustainability/get', products_sustainability_get, name='products_sustainability_get'),
    path('products/sustainability/pagination', products_sustainability_pagination, name='products_sustainability_pagination'),
    path('products/sustainability/add', products_sustainability_add, name='products_sustainability_add'),
    path('products/sustainability/edit', products_sustainability_edit, name='products_sustainability_edit'),
    path('products/sustainability/delete', products_sustainability_delete, name='products_sustainability_delete'),

    path('products/fit/get', products_fit_get, name='products_fit_get'),
    path('products/fit/pagination', products_fit_pagination, name='products_fit_pagination'),
    path('products/fit/add', products_fit_add, name='products_fit_add'),
    path('products/fit/edit', products_fit_edit, name='products_fit_edit'),
    path('products/fit/delete', products_fit_delete, name='products_fit_delete'),

    path('products/size-range/get', products_size_range_get, name='products_size_range_get'),
    path('products/size-range/pagination', products_size_range_pagination, name='products_size_range_pagination'),
    path('products/size-range/add', products_size_range_add, name='products_size_range_add'),
    path('products/size-range/edit', products_size_range_edit, name='products_size_range_edit'),
    path('products/size-range/delete', products_size_range_delete, name='products_size_range_delete'),

    path('products/attributes/get', products_attributes_get, name='products_attributes_get'),
    path('products/attributes/pagination', products_attributes_pagination, name='products_attributes_pagination'),
    path('products/attributes/add', products_attributes_add, name='products_attributes_add'),
    path('products/attributes/edit', products_attributes_edit, name='products_attributes_edit'),
    path('products/attributes/delete', products_attributes_delete, name='products_attributes_delete'),

    path('products/reviews/get', products_reviews_get, name='products_reviews_get'),
    path('products/reviews/pagination', products_reviews_pagination, name='products_reviews_pagination'),
    path('products/reviews/add', products_reviews_add, name='products_reviews_add'),
    path('products/reviews/edit', products_reviews_edit, name='products_reviews_edit'),
    path('products/reviews/delete', products_reviews_delete, name='products_reviews_delete'),

    path('products/upload/image/add', products_image_add, name='products_image_add'),
    path('products/upload/image/delete', products_image_delete, name='products_image_delete'),

    path('upload/image/add', image_add, name='image_add'),
    path('upload/image/delete', image_delete, name='image_delete'),


    # Staff endpoints
    path('staff/allstaff/get', staff_get, name='staffstaff_get'),
    path('staff/allstaff/pagination', staff_pagination, name='staffstaff_pagination'),
    path('staff/allstaff/add', staff_add, name='staffstaff_add'),
    path('staff/allstaff/edit', staff_edit, name='staffstaff_edit'),
    path('staff/allstaff/delete', staff_delete, name='staffstaff_delete'),

    path('staff/roles/get', staff_roles_get, name='staff_roles_get'),
    path('staff/roles/pagination', staff_roles_pagination, name='staff_roles_pagination'),
    path('staff/roles/add', staff_roles_add, name='staff_roles_add'),
    path('staff/roles/edit', staff_roles_edit, name='staff_roles_edit'),
    path('staff/roles/delete', staff_roles_delete, name='staff_roles_delete'),

    path('staff/permissions/get', staff_permissions_get, name='staff_permissions_get'),
    path('staff/permissions/pagination', staff_permissions_pagination, name='staff_permissions_pagination'),
    path('staff/permissions/add', staff_permissions_add, name='staff_permissions_add'),
    path('staff/permissions/edit', staff_permissions_edit, name='staff_permissions_edit'),
    path('staff/permissions/delete', staff_permissions_delete, name='staff_permissions_delete'),

    path('staff/activity/get', staff_activity_get, name='staff_activity_get'),
    path('staff/activity/pagination', staff_activity_pagination, name='staff_activity_pagination'),
    path('staff/activity/add', staff_activity_add, name='staff_activity_add'),
    path('staff/activity/edit', staff_activity_edit, name='staff_activity_edit'),
    path('staff/activity/delete', staff_activity_delete, name='staff_activity_delete'),

    # Order endpoints
    path('order/pending/get', order_pending_get, name='order_pending_get'),
    path('order/pending/pagination', order_pending_pagination, name='order_pending_pagination'),
    path('order/pending/add', order_pending_add, name='order_pending_add'),
    path('order/pending/edit', order_pending_edit, name='order_pending_edit'),
    path('order/pending/delete', order_pending_delete, name='order_pending_delete'),

    path('order/processing/get', order_processing_get, name='order_processing_get'),
    path('order/processing/pagination', order_processing_pagination, name='order_processing_pagination'),
    path('order/processing/add', order_processing_add, name='order_processing_add'),
    path('order/processing/edit', order_processing_edit, name='order_processing_edit'),
    path('order/processing/delete', order_processing_delete, name='order_processing_delete'),

    path('order/complete/get', order_complete_get, name='order_complete_get'),
    path('order/complete/pagination', order_complete_pagination, name='order_complete_pagination'),
    path('order/complete/add', order_complete_add, name='order_complete_add'),
    path('order/complete/edit', order_complete_edit, name='order_complete_edit'),
    path('order/complete/delete', order_complete_delete, name='order_complete_delete'),

    path('order/all/get', order_get, name='order_get'),
    path('order/all/pagination', order_pagination, name='order_pagination'),
    path('order/all/add', order_add, name='order_add'),
    path('order/all/edit', order_edit, name='order_edit'),
    path('order/all/delete', order_delete, name='order_delete'),

    # Users endpoints (example for requests, repeat for all user types)
    path('users/reqyests/get', users_requests_get, name='users_requests_get'),
    path('users/reqyests/pagination', users_requests_pagination, name='users_requests_pagination'),
    path('users/reqyests/add', users_requests_add, name='users_requests_add'),
    path('users/reqyests/edit', users_requests_edit, name='users_requests_edit'),
    path('users/reqyests/delete', users_requests_delete, name='users_requests_delete'),

    path('users/admin/get', users_admin_get, name='users_admin_get'),
    path('users/admin/pagination', users_admin_pagination, name='users_admin_pagination'),
    path('users/admin/add', users_admin_add, name='users_admin_add'),
    path('users/admin/edit', users_admin_edit, name='users_admin_edit'),
    path('users/admin/delete', users_admin_delete, name='users_admin_delete'),

    path('users/moderator/get', users_moderator_get, name='users_moderator_get'),
    path('users/moderator/pagination', users_moderator_pagination, name='users_moderator_pagination'),
    path('users/moderator/add', users_moderator_add, name='users_moderator_add'),
    path('users/moderator/edit', users_moderator_edit, name='users_moderator_edit'),
    path('users/moderator/delete', users_moderator_delete, name='users_moderator_delete'),

    path('users/support/get', users_support_get, name='users_support_get'),
    path('users/support/pagination', users_support_pagination, name='users_support_pagination'),
    path('users/support/add', users_support_add, name='users_support_add'),
    path('users/support/edit', users_support_edit, name='users_support_edit'),
    path('users/support/delete', users_support_delete, name='users_support_delete'),

    path('users/deliveryman/get', users_deliveryman_get, name='users_deliveryman_get'),
    path('users/deliveryman/pagination', users_deliveryman_pagination, name='users_deliveryman_pagination'),
    path('users/deliveryman/add', users_deliveryman_add, name='users_deliveryman_add'),
    path('users/deliveryman/edit', users_deliveryman_edit, name='users_deliveryman_edit'),
    path('users/deliveryman/delete', users_deliveryman_delete, name='users_deliveryman_delete'),

    path('users/company/get', users_company_get, name='users_company_get'),
    path('users/company/pagination', users_company_pagination, name='users_company_pagination'),
    path('users/company/add', users_company_add, name='users_company_add'),
    path('users/company/edit', users_company_edit, name='users_company_edit'),
    path('users/company/delete', users_company_delete, name='users_company_delete'),

    path('users/customer/get', users_customer_get, name='users_customer_get'),
    path('users/customer/pagination', users_customer_pagination, name='users_customer_pagination'),
    path('users/customer/add', users_customer_add, name='users_customer_add'),
    path('users/customer/edit', users_customer_edit, name='users_customer_edit'),
    path('users/customer/delete', users_customer_delete, name='users_customer_delete'),

    path('users/guest/get', users_guest_get, name='users_guest_get'),
    path('users/guest/pagination', users_guest_pagination, name='users_guest_pagination'),
    path('users/guest/add', users_guest_add, name='users_guest_add'),
    path('users/guest/edit', users_guest_edit, name='users_guest_edit'),
    path('users/guest/delete', users_guest_delete, name='users_guest_delete'),

    path('users/usercontrol/get', users_usercontrol_get, name='users_usercontrol_get'),
    path('users/usercontrol/pagination', users_usercontrol_pagination, name='users_usercontrol_pagination'),
    path('users/usercontrol/add', users_usercontrol_add, name='users_usercontrol_add'),
    path('users/usercontrol/edit', users_usercontrol_edit, name='users_usercontrol_edit'),
    path('users/usercontrol/delete', users_usercontrol_delete, name='users_usercontrol_delete'),

    path('users/managepermissions/get', users_managepermissions_get, name='users_managepermissions_get'),
    path('users/managepermissions/pagination', users_managepermissions_pagination, name='users_managepermissions_pagination'),
    path('users/managepermissions/add', users_managepermissions_add, name='users_managepermissions_add'),
    path('users/managepermissions/edit', users_managepermissions_edit, name='users_managepermissions_edit'),
    path('users/managepermissions/delete', users_managepermissions_delete, name='users_managepermissions_delete'),

    # Brandsclients endpoints
    path('brandsclients/get', brandsclients_get, name='brandsclients_get'),
    path('brandsclients/pagination', brandsclients_pagination, name='brandsclients_pagination'),
    path('brandsclients/add', brandsclients_add, name='brandsclients_add'),
    path('brandsclients/edit', brandsclients_edit, name='brandsclients_edit'),
    path('brandsclients/delete', brandsclients_delete, name='brandsclients_delete'),
    path('brandsclients/avatar/upload', brandsclients_avatar_upload, name='brandsclients_avatar_upload'),  

    # Message endpoints
    path('message/get', message_get, name='message_get'),
    path('message/pagination', message_pagination, name='message_pagination'),
    path('message/add', message_add, name='message_add'),
    path('message/edit', message_edit, name='message_edit'),
    path('message/delete', message_delete, name='message_delete'),

    # Transactions endpoints
    path('transactions/all/get', transactions_get, name='transactions_get'),
    path('transactions/all/pagination', transactions_pagination, name='transactions_pagination'),
    path('transactions/all/add', transactions_add, name='transactions_add'),
    path('transactions/all/edit', transactions_edit, name='transactions_edit'),
    path('transactions/all/delete', transactions_delete, name='transactions_delete'),

    path('transactions/incomming/get', transactions_incomming_get, name='transactions_incomming_get'),
    path('transactions/incomming/pagination', transactions_incomming_pagination, name='transactions_incomming_pagination'),
    path('transactions/incomming/add', transactions_incomming_add, name='transactions_incomming_add'),
    path('transactions/incomming/edit', transactions_incomming_edit, name='transactions_incomming_edit'),
    path('transactions/incomming/delete', transactions_incomming_delete, name='transactions_incomming_delete'),

    path('transactions/outgoging/get', transactions_outgoging_get, name='transactions_outgoging_get'),
    path('transactions/outgoging/pagination', transactions_outgoging_pagination, name='transactions_outgoging_pagination'),
    path('transactions/outgoging/add', transactions_outgoging_add, name='transactions_outgoging_add'),
    path('transactions/outgoging/edit', transactions_outgoging_edit, name='transactions_outgoging_edit'),
    path('transactions/outgoging/delete', transactions_outgoging_delete, name='transactions_outgoging_delete'),

    # Marketing endpoints
    path('marketing/coupons/get', marketing_coupons_get, name='marketing_coupons_get'),
    path('marketing/coupons/pagination', marketing_coupons_pagination, name='marketing_coupons_pagination'),
    path('marketing/coupons/add', marketing_coupons_add, name='marketing_coupons_add'),
    path('marketing/coupons/edit', marketing_coupons_edit, name='marketing_coupons_edit'),
    path('marketing/coupons/delete', marketing_coupons_delete, name='marketing_coupons_delete'),

    path('marketing/campaigns/get', marketing_campaigns_get, name='marketing_campaigns_get'),
    path('marketing/campaigns/pagination', marketing_campaigns_pagination, name='marketing_campaigns_pagination'),
    path('marketing/campaigns/add', marketing_campaigns_add, name='marketing_campaigns_add'),
    path('marketing/campaigns/edit', marketing_campaigns_edit, name='marketing_campaigns_edit'),
    path('marketing/campaigns/delete', marketing_campaigns_delete, name='marketing_campaigns_delete'),

    path('marketing/banners/get', marketing_banners_get, name='marketing_banners_get'),
    path('marketing/banners/pagination', marketing_banners_pagination, name='marketing_banners_pagination'),
    path('marketing/banners/add', marketing_banners_add, name='marketing_banners_add'),
    path('marketing/banners/edit', marketing_banners_edit, name='marketing_banners_edit'),
    path('marketing/banners/delete', marketing_banners_delete, name='marketing_banners_delete'),

    path('marketing/newsletters/get', marketing_newsletters_get, name='marketing_newsletters_get'),
    path('marketing/newsletters/pagination', marketing_newsletters_pagination, name='marketing_newsletters_pagination'),
    path('marketing/newsletters/add', marketing_newsletters_add, name='marketing_newsletters_add'),
    path('marketing/newsletters/edit', marketing_newsletters_edit, name='marketing_newsletters_edit'),
    path('marketing/newsletters/delete', marketing_newsletters_delete, name='marketing_newsletters_delete'),

    # Reports endpoints
    path('reports/sales/get', reports_sales_get, name='reports_sales_get'),
    path('reports/sales/pagination', reports_sales_pagination, name='reports_sales_pagination'),
    path('reports/sales/add', reports_sales_add, name='reports_sales_add'),
    path('reports/sales/edit', reports_sales_edit, name='reports_sales_edit'),
    path('reports/sales/delete', reports_sales_delete, name='reports_sales_delete'),

    path('reports/customers/get', reports_customers_get, name='reports_customers_get'),
    path('reports/customers/pagination', reports_customers_pagination, name='reports_customers_pagination'),
    path('reports/customers/add', reports_customers_add, name='reports_customers_add'),
    path('reports/customers/edit', reports_customers_edit, name='reports_customers_edit'),
    path('reports/customers/delete', reports_customers_delete, name='reports_customers_delete'),

    path('reports/products/get', reports_products_get, name='reports_products_get'),
    path('reports/products/pagination', reports_products_pagination, name='reports_products_pagination'),
    path('reports/products/add', reports_products_add, name='reports_products_add'),
    path('reports/products/edit', reports_products_edit, name='reports_products_edit'),
    path('reports/products/delete', reports_products_delete, name='reports_products_delete'),

    path('reports/stock/get', reports_stock_get, name='reports_stock_get'),
    path('reports/stock/pagination', reports_stock_pagination, name='reports_stock_pagination'),
    path('reports/stock/add', reports_stock_add, name='reports_stock_add'),
    path('reports/stock/edit', reports_stock_edit, name='reports_stock_edit'),
    path('reports/stock/delete', reports_stock_delete, name='reports_stock_delete'),

    path('reports/finance/get', reports_finance_get, name='reports_finance_get'),
    path('reports/finance/pagination', reports_finance_pagination, name='reports_finance_pagination'),
    path('reports/finance/add', reports_finance_add, name='reports_finance_add'),
    path('reports/finance/edit', reports_finance_edit, name='reports_finance_edit'),
    path('reports/finance/delete', reports_finance_delete, name='reports_finance_delete'),

    # CMS endpoints (example for blogs, repeat for all submodules)
    path('cms/blogs/get', blogs_get, name='blogs_get'),
    path('cms/blogs/pagination', blogs_pagination, name='blogs_pagination'),
    path('cms/blogs/add', blogs_add, name='blogs_add'),
    path('cms/blogs/edit', blogs_edit, name='blogs_edit'), 
    path('cms/blogs/edit/<int:blog_id>', blogs_edit, name='blogs_edit_with_id'),
    path('cms/blogs/delete', blogs_delete, name='blogs_delete'),
    path('cms/blogs/detail/<int:blog_id>', blogs_detail, name='blogs_detail'),  

    path('cms/blogs/category/get', blogs_category_get, name='blogs_category_get'),
    path('cms/blogs/category/pagination', blogs_category_pagination, name='blogs_category_pagination'),
    path('cms/blogs/category/add', blogs_category_add, name='blogs_category_add'),
    path('cms/blogs/category/edit', blogs_category_edit, name='blogs_category_edit'),
    path('cms/blogs/category/delete', blogs_category_delete, name='blogs_category_delete'),

    # CMS endpoints for pages
    path('cms/pages/get', cms_pages_get, name='cms_pages_get'),
    path('cms/pages/pagination', cms_pages_pagination, name='cms_pages_pagination'),
    path('cms/pages/add', cms_pages_add, name='cms_pages_add'),
    path('cms/pages/edit', cms_pages_edit, name='cms_pages_edit'),
    path('cms/pages/delete', cms_pages_delete, name='cms_pages_delete'),

    path('cms/pages/category/get', cms_category_get, name='cms_category_get'),
    path('cms/pages/category/pagination', cms_category_pagination, name='cms_category_pagination'),
    path('cms/pages/category/add', cms_category_add, name='cms_category_add'),
    path('cms/pages/category/edit', cms_category_edit, name='cms_category_edit'),
    path('cms/pages/category/delete', cms_category_delete, name='cms_category_delete'),

    # CMS endpoints for menus
    path('cms/menus/get', cms_menus_get, name='cms_menus_get'),
    path('cms/menus/pagination', cms_menus_pagination, name='cms_menus_pagination'),
    path('cms/menus/add', cms_menus_add, name='cms_menus_add'),
    path('cms/menus/edit', cms_menus_edit, name='cms_menus_edit'),
    path('cms/menus/delete', cms_menus_delete, name='cms_menus_delete'),


    path('cms/menus/category/get', menu_category_get, name='menu_category_get'),
    path('cms/menus/category/pagination', menu_category_pagination, name='menu_category_pagination'),
    path('cms/menus/category/add', menu_category_add, name='menu_category_add'),
    path('cms/menus/category/edit', menu_category_edit, name='menu_category_edit'),
    path('cms/menus/category/delete', menu_category_delete, name='menu_category_delete'),

    # CMS endpoints for media
    path('cms/media/get', cms_media_get, name='cms_media_get'),
    path('cms/media/pagination', cms_media_pagination, name='cms_media_pagination'),
    path('cms/media/add', cms_media_add, name='cms_media_add'),
    path('cms/media/edit', cms_media_edit, name='cms_media_edit'),
    path('cms/media/delete', cms_media_delete, name='cms_media_delete'),


    path('cms/media/category/get', media_category_get, name='media_category_get'),
    path('cms/media/category/pagination', media_category_pagination, name='media_category_pagination'),
    path('cms/media/category/add', media_category_add, name='media_category_add'),
    path('cms/media/category/edit', media_category_edit, name='media_category_edit'),
    path('cms/media/category/delete', media_category_delete, name='media_category_delete'),

    # ...existing code...
]
