from django.shortcuts import render

def pages_all(request):
    return render(request, 'mainadmin/cms/pages/all.html')

def pages_add(request):
    return render(request, 'mainadmin/cms/pages/add.html')

def pages_category(request):
    return render(request, 'mainadmin/cms/pages/category.html')
