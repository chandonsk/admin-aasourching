from django.shortcuts import render

def menus_all(request):
    return render(request, 'mainadmin/cms/menus/all.html')

def menus_add(request):
    return render(request, 'mainadmin/cms/menus/add.html')

def menus_category(request):
    return render(request, 'mainadmin/cms/menus/category.html')
