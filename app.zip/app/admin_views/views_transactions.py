from django.shortcuts import render

def transactions_all(request):
    return render(request, 'mainadmin/transactions/all.html')
def transactions_incomming(request):
    return render(request, 'mainadmin/transactions/incomming.html')
def transactions_outgoging(request):
    return render(request, 'mainadmin/transactions/outgoging.html')

__all__ = ['transactions_incomming', 'transactions_outgoging']
