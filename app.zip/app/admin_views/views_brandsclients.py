from django.shortcuts import render

def brandsclients(request):
    return render(request, 'mainadmin/brandsclients.html')

__all__ = ['brandsclients']
