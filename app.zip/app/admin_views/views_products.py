from django.shortcuts import render
from django.http import HttpResponse

def products_all(request):
    return render(request, 'mainadmin/products/all.html')
def products_add(request):
    return render(request, 'mainadmin/products/add.html')
def products_view(request, product_id):
    return render(request, 'mainadmin/products/view.html')
def products_edit(request, product_id):
    return render(request, 'mainadmin/products/edit.html')

def product_brand(request):
    return render(request, 'mainadmin/products/brand.html')
def products_line(request):
    return render(request, 'mainadmin/products/line.html')
def products_category(request):
    return render(request, 'mainadmin/products/category.html')
def products_colors(request):
    return render(request, 'mainadmin/products/colors.html')
def products_sustainability(request):
    return render(request, 'mainadmin/products/sustainability.html')
def products_fit(request):
    return render(request, 'mainadmin/products/fit.html')
def products_size_range(request):
    return render(request, 'mainadmin/products/size_range.html')
def products_attributes(request):
    return render(request, 'mainadmin/products/attributes.html')
def products_reviews(request):
    return render(request, 'mainadmin/products/reviews.html')

__all__ = [
    'products_all','products_add', 'products_edit', 'products_line', 'products_category', 'products_colors', 'products_sustainability',
    'products_fit', 'products_size_range', 'products_attributes', 'products_reviews'
]
