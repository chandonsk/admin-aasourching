from django.shortcuts import render

def reports_sales(request):
    return render(request, 'mainadmin/reports/sales.html')
def reports_customers(request):
    return render(request, 'mainadmin/reports/customers.html')
def reports_products(request):
    return render(request, 'mainadmin/reports/products.html')
def reports_stock(request):
    return render(request, 'mainadmin/reports/stock.html')
def reports_finance(request):
    return render(request, 'mainadmin/reports/finance.html')

__all__ = ['reports_sales', 'reports_customers', 'reports_products', 'reports_stock', 'reports_finance']
