from django.shortcuts import render
from django.http import HttpResponse

def order_pending(request):
    return render(request, 'mainadmin/order/pending.html')
def order_processing(request):
    return render(request, 'mainadmin/order/processing.html')
def order_complete(request):
    return render(request, 'mainadmin/order/complete.html')
def order_all(request):
    return render(request, 'mainadmin/order/all.html')

__all__ = [
    'order_pending', 'order_processing', 'order_complete', 'order_all'
]
