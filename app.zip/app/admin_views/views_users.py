from django.shortcuts import render
from django.http import HttpResponse

def users_all(request):
    return render(request, 'mainadmin/users/all.html', {'title': 'Users All'})
def users_requests(request):
    return HttpResponse('Users Requests')
def users_admin(request):
    return render(request, 'mainadmin/users/admin.html', {'title': 'Users Admin'})
def users_moderator(request):
    return render(request, 'mainadmin/users/moderator.html', {'title': 'Moderator Users'})
def users_support(request):
    return render(request, 'mainadmin/users/support.html', {'title': 'Support Users'})
def users_deliveryman(request):
    return render(request, 'mainadmin/users/deliveryman.html', {'title': 'DeliveryMan Users'})
def users_company(request):
    return render(request, 'mainadmin/users/company.html', {'title': 'Company Users'})
def users_customer(request):
    return render(request, 'mainadmin/users/customer.html', {'title': 'Customer Users'})
def users_guest(request):
    return render(request, 'mainadmin/users/guest.html', {'title': 'Guest Users'})
def users_usercontrol(request):
    return HttpResponse('Users User Control')
def users_managepermissions(request):
    return HttpResponse('Users Manage Permissions')

__all__ = [
    'users_all', 'users_requests', 'users_admin', 'users_moderator', 'users_support', 'users_deliveryman',
    'users_company', 'users_customer', 'users_guest', 'users_usercontrol', 'users_managepermissions'
]
