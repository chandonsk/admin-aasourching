from django.urls import path, include
from .views import mainadmin_index
from .views_users import (
    users_all, users_requests, users_admin, users_moderator, users_support, users_deliveryman,
    users_company, users_customer, users_guest, users_usercontrol, users_managepermissions
)
from .views_products import (
    products_all, products_add, products_view, products_edit, product_brand, products_line, products_category, products_colors, products_sustainability,
    products_fit, products_size_range, products_attributes, products_reviews,
)
from .views_order import (
    order_pending, order_processing, order_complete, order_all
)
from .views_blogs import (
    blogs_all, blogs_add, blogs_category, blogs_edit
)
from .views_staff import (
    staff_allstaff, staff_roles, staff_permissions, staff_activity
)
from .views_brandsclients import brandsclients
from .views_message import message
from .views_transactions import transactions_all, transactions_incomming, transactions_outgoging
from .views_marketing import marketing_coupons, marketing_campaigns, marketing_banners, marketing_newsletters
from .views_reports import reports_sales, reports_customers, reports_products, reports_stock, reports_finance
from .views_cms import cms_pages, cms_pages_add, cms_category, cms_menus, cms_menus_add, menu_category, cms_media, cms_media_add, media_category
from .views_support import support_tickets, support_faq, support_contact
from .views_notifications import notifications_all, notifications_logs
from .views_settings import settings_general, settings_payment, settings_shipping, settings_taxes, settings_localization, settings_email
from .views_account import (
    account_profile, account_balance, account_settings, account_security, account_notifications
)

app_name = 'mainadmin'

urlpatterns = [
    path('', mainadmin_index, name='mainadmin_index'),
    path('products/', include([
        path('all', products_all, name='products_all'),
        path('add', products_add, name='products_add'),
        path('view/<int:product_id>', products_view, name='products_view'),
        path('edit/<int:product_id>', products_edit, name='products_edit'),  # <-- Add this line
        path('line', products_line, name='products_line'),
        path('category', products_category, name='products_category'),
        path('colors', products_colors, name='products_colors'),
        path('sustainability', products_sustainability, name='products_sustainability'),
        path('fit', products_fit, name='products_fit'),
        path('size-range', products_size_range, name='products_size_range'),
        path('attributes', products_attributes, name='products_attributes'),
        path('reviews', products_reviews, name='products_reviews'),
        path('brand', product_brand, name='product_brand'),
    ])),
    path('order/', include([
        path('pending', order_pending, name='order_pending'),
        path('processing', order_processing, name='order_processing'),
        path('complete', order_complete, name='order_complete'),
        path('all', order_all, name='order_all'),
    ])),
    path('users/', include([
        path('all', users_all, name='users_all'),
        path('reqyests', users_requests, name='users_requests'),
        path('admin', users_admin, name='users_admin'),
        path('moderator', users_moderator, name='users_moderator'),
        path('support', users_support, name='users_support'),
        path('deliveryman', users_deliveryman, name='users_deliveryman'),
        path('company', users_company, name='users_company'),
        path('customer', users_customer, name='users_customer'),
        path('guest', users_guest, name='users_guest'),
        path('usercontrol', users_usercontrol, name='users_usercontrol'),
        path('managepermissions', users_managepermissions, name='users_managepermissions'),
    ])),
    path('staff/', include([
        path('allstaff', staff_allstaff, name='staff_allstaff'),
        path('roles', staff_roles, name='staff_roles'),
        path('permissions', staff_permissions, name='staff_permissions'),
        path('activity', staff_activity, name='staff_activity'),
    ])),

    path('brandsclients/', brandsclients, name='brandsclients'),
    path('message/', message, name='message'),
    path('transactions/', include([
        path('all', transactions_all, name='transactions_all'),
        path('incomming', transactions_incomming, name='transactions_incomming'),
        path('outgoging', transactions_outgoging, name='transactions_outgoging'),
    ])),
    path('marketing/', include([
        path('coupons', marketing_coupons, name='marketing_coupons'),
        path('campaigns', marketing_campaigns, name='marketing_campaigns'),
        path('banners', marketing_banners, name='marketing_banners'),
        path('newsletters', marketing_newsletters, name='marketing_newsletters'),
    ])),
    path('reports/', include([
        path('sales', reports_sales, name='reports_sales'),
        path('customers', reports_customers, name='reports_customers'),
        path('products', reports_products, name='reports_products'),
        path('stock', reports_stock, name='reports_stock'),
        path('finance', reports_finance, name='reports_finance'),
    ])),
    path('cms/', include([
        path('blogs/', include([
            path('all', blogs_all, name='blogs_all'),
            path('add', blogs_add, name='blogs_add'),
            path('edit/<int:blog_id>', blogs_edit, name='blogs_edit'),
            path('category', blogs_category, name='blogs_category'),
        ])),
        path('pages/', include([
            path('all', cms_pages, name='cms_pages_all'),
            path('add', cms_pages_add, name='cms_pages_add'),
            path('category', cms_category, name='cms_pages_category'),
        ])),
        path('menus/', include([
            path('all', cms_menus, name='cms_menus_all'),
            path('add', cms_menus_add, name='cms_menus_add'),
            path('category', menu_category, name='cms_menus_category'),
        ])),
        path('media/', include([
            path('all', cms_media, name='cms_media_all'),
            path('add', cms_media_add, name='cms_media_add'),
            path('category', media_category, name='cms_media_category'),
        ])),
    ])),

    path('support/', include([
        path('tickets', support_tickets, name='support_tickets'),
        path('faq', support_faq, name='support_faq'),
        path('contact', support_contact, name='support_contact'),
    ])),
    path('notifications/', include([
        path('all', notifications_all, name='notifications_all'),
        path('logs', notifications_logs, name='notifications_logs'),
    ])),
    path('settings/', include([
        path('general', settings_general, name='settings_general'),
        path('payment', settings_payment, name='settings_payment'),
        path('shipping', settings_shipping, name='settings_shipping'),
        path('taxes', settings_taxes, name='settings_taxes'),
        path('localization', settings_localization, name='settings_localization'),
        path('email', settings_email, name='settings_email'),
    ])),
    path('account/', include([
        path('profile', account_profile, name='account_profile'),
        path('balance', account_balance, name='account_balance'),
        path('settings', account_settings, name='account_settings'),
        path('security', account_security, name='account_security'),
        path('notifications', account_notifications, name='account_notifications'),
    ])),
]