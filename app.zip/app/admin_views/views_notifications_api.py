# views_notifications_api.py
# Add your API notifications-related view functions here.
