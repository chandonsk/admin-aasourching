from django.shortcuts import render

def cms_pages(request):
    return render(request, 'mainadmin/cms/pages/all.html')
def cms_pages_add(request):
    return render(request, 'mainadmin/cms/pages/add.html')
def cms_category(request):
    return render(request, 'mainadmin/cms/pages/category.html')

def cms_menus(request):
    return render(request, 'mainadmin/cms/menus/all.html')
def cms_menus_add(request):
    return render(request, 'mainadmin/cms/menus/add.html')
def menu_category(request):
    return render(request, 'mainadmin/cms/menus/category.html')

def cms_media(request):
    return render(request, 'mainadmin/cms/media/all.html')
def cms_media_add(request):
    return render(request, 'mainadmin/cms/media/add.html')
def media_category(request):
    return render(request, 'mainadmin/cms/media/category.html')

__all__ = [
    'cms_pages', 'cms_pages_add', 'cms_category',
    'cms_menus', 'cms_menus_add', 'menu_category',
    'cms_media', 'cms_media_add', 'media_category',
]
