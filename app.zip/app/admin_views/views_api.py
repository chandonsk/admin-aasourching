# views.py

from django.shortcuts import render, redirect
from django.http import JsonResponse
from app.models.user.common import Users


app_name = 'main_admin_api'

def mainadmin_api(request):
    user_id = request.session.get('user_id')
    user_type = request.session.get('user_type')
    if not user_id or user_type != 1:
        return JsonResponse({'status': 'error', 'message': 'Unauthorized access'}, status=401)
    #user = Users.objects.get(id=user_id)
    # Only redirect to notverified if BOTH are False (0)
    #if not (user.is_email_verified or user.is_phone_verified):
    #    return redirect('/myadmin/notverified')
    return render(request, 'mainadmin/index.html')#, {'user': user})

# REMOVE urlpatterns from this file!
# urlpatterns should only be defined in your urls_api.py or similar routing file.