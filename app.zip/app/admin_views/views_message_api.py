# views_message_api.py
# Add your API message-related view functions here.
