from django.shortcuts import render
from django.http import HttpResponse

def blogs_all(request):
    return render(request, 'mainadmin/cms/blogs/all.html')
def blogs_add(request):
    return render(request, 'mainadmin/cms/blogs/add.html')
def blogs_category(request):
    return render(request, 'mainadmin/cms/blogs/category.html')
def blogs_edit(request, blog_id):
    return render(request, 'mainadmin/cms/blogs/edit.html', {'blog_id': blog_id})

__all__ = [
    'blogs_all', 'blogs_add', 'blogs_category', 'blogs_edit'
]
