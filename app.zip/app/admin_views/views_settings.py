from django.shortcuts import render

def settings_general(request):
    return render(request, 'mainadmin/settings/general.html')
def settings_payment(request):
    return render(request, 'mainadmin/settings/payment.html')
def settings_shipping(request):
    return render(request, 'mainadmin/settings/shipping.html')
def settings_taxes(request):
    return render(request, 'mainadmin/settings/taxes.html')
def settings_localization(request):
    return render(request, 'mainadmin/settings/localization.html')
def settings_email(request):
    return render(request, 'mainadmin/settings/email.html')

__all__ = ['settings_general', 'settings_payment', 'settings_shipping', 'settings_taxes', 'settings_localization', 'settings_email']
