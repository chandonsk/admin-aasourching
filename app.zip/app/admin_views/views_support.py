from django.shortcuts import render

def support_tickets(request):
    return render(request, 'mainadmin/support/tickets.html')
def support_faq(request):
    return render(request, 'mainadmin/support/faq.html')
def support_contact(request):
    return render(request, 'mainadmin/support/contact.html')

__all__ = ['support_tickets', 'support_faq', 'support_contact']
