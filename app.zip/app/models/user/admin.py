# app/models/admin.py
from django.db import models
from .common import Users

class AdminManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(user_type=1)

class Admin(Users):
    objects = AdminManager()
    class Meta:
        proxy = True
        verbose_name = 'Admin'
        verbose_name_plural = 'Admins'