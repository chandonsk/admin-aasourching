from django.db import models
from .common import Users

class ModeratorManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(user_type=2)

class Moderator(Users):
    objects = ModeratorManager()
    class Meta:
        proxy = True
        verbose_name = 'Moderator'
        verbose_name_plural = 'Moderators'
