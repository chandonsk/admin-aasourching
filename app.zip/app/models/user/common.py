from django.db import models

class Users(models.Model):
    USER_TYPES = (
        (1, 'Admin'),
        (2, 'Moderator'),
        (3, 'Support'), 
        (4, 'DeliveryMan'),       
        (5, 'Company'), 
        (6, 'Customer'), 
        (9, 'Guest'), 
    )

    id = models.BigAutoField(primary_key=True)
    user_type = models.IntegerField(choices=USER_TYPES, default=6)
    is_staff = models.BooleanField(default=False)
    staff_roles = models.CharField(max_length=255, null=True, blank=True) 
    is_active = models.BooleanField(default=True)
    country_id = models.IntegerField()
    full_name = models.CharField(max_length=255)
    national_id = models.CharField(max_length=50, null=True, blank=True) 
    date_of_birth = models.DateField(null=True, blank=True)
    user_name = models.CharField(max_length=255, null=True, blank=True)
    email = models.CharField(max_length=255, unique=True)
    phone_number = models.CharField(max_length=20, null=True, blank=True)  
    password = models.TextField()
    loyalty_points = models.IntegerField(default=0)
    is_premium_member = models.BooleanField(default=False)
    company_name = models.CharField(max_length=255, null=True, blank=True)
    company_address = models.CharField(max_length=255, null=True, blank=True)
    newsletter_subscribed = models.BooleanField(default=False)
    is_email_verified = models.BooleanField(default=False)
    is_phone_verified = models.BooleanField(default=False)
    user_otp = models.CharField(max_length=10, blank=True, null=True)
    registered_date = models.DateTimeField(auto_now_add=True)
    profile_image = models.ImageField(upload_to='profile_images/', null=True, blank=True)
    last_login = models.DateTimeField(null=True, blank=True)
    last_activity = models.DateTimeField(null=True, blank=True)
    gender = models.CharField(max_length=10, choices=(('male', 'Male'), ('female', 'Female'), ('other', 'Other')), null=True, blank=True)
    preferred_language = models.CharField(max_length=10, null=True, blank=True, default='en')
    referral_code = models.CharField(max_length=50, null=True, blank=True)
    STATUS_CHOICES = (
        (1, 'Active'),
        (0, 'Inactive'),
        (-1, 'Deleted'),
    )
    status = models.SmallIntegerField(
        default=1,
        choices=STATUS_CHOICES,
    )

    def __str__(self):
        return f"{self.full_name} ({self.get_user_type_display()})"






