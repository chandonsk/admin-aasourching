from django.db import models
from .common import Users

class CompanyManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(user_type=5)

class Company(Users):
    objects = CompanyManager()
    class Meta:
        proxy = True
        verbose_name = 'Company'
        verbose_name_plural = 'Companies'
