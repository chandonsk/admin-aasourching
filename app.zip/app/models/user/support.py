from django.db import models
from .common import Users

class SupportManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(user_type=3)

class Support(Users):
    objects = SupportManager()
    class Meta:
        proxy = True
        verbose_name = 'Support'
        verbose_name_plural = 'Supports'
