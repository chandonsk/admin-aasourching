from django.db import models
from .common import Users

class CustomerManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(user_type=6)

class Customer(Users):
    objects = CustomerManager()
    class Meta:
        proxy = True
        verbose_name = 'Customer'
        verbose_name_plural = 'Customers'
