from django.db import models
from .common import Users

class DeliveryManManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(user_type=4)

class DeliveryMan(Users):
    objects = DeliveryManManager()
    class Meta:
        proxy = True
        verbose_name = 'DeliveryMan'
        verbose_name_plural = 'DeliveryMen'
