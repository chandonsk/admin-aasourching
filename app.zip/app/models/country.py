from django.db import models

class Country(models.Model):
    name = models.CharField(max_length=80)
    iso_alpha2 = models.CharField(max_length=2, unique=True)
    iso_alpha3 = models.CharField(max_length=3, unique=True)
    phone_code = models.IntegerField(null=True, blank=True)
    capital = models.CharField(max_length=80, null=True, blank=True)
    # Add other fields as needed

    def __str__(self):
        return f"{self.name} ({self.iso_alpha2})"