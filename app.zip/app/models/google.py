from django.db import models
class GoogleAccess(models.Model):
    email = models.CharField(max_length=255, unique=True, null=True, blank=True)
    credentials = models.TextField()
    # id field is auto-created as primary key by Django

    def __str__(self):
        return self.email or f"GoogleAccess {self.pk}"
