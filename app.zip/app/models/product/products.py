from django.db import models
from .lines import ProductLine
from .categories import ProductCategory
from .sustainability import ProductSustainability
from .colors import ProductColor
from .size_range import ProductSizeRange
from .fit import ProductFit
from .brand import ProductBrand
from app.models.upload import ImageByToken

class Products(models.Model):
    GENDER_CHOICES = (
        (1, 'Men'),
        (2, 'Women'),
        (3, 'Unisex'),
        (4, 'Children'),
    )
    id = models.BigAutoField(primary_key=True)
    product_slug = models.CharField(max_length=255, unique=True,null=True,)  
    brand = models.ForeignKey(
        ProductBrand, on_delete=models.SET_NULL, null=True, blank=True, related_name='products'
    )
    productline = models.ForeignKey(
        ProductLine, on_delete=models.SET_NULL, null=True, blank=True, related_name='products'
    )
    category = models.ForeignKey(
        ProductCategory, on_delete=models.SET_NULL, null=True, blank=True, related_name='products'
    )
    sustainability = models.ForeignKey(
        ProductSustainability, on_delete=models.SET_NULL, null=True, blank=True, related_name='products'
    )
    colors = models.ManyToManyField(
        ProductColor, blank=True, related_name='products'
    )
    
    min_size = models.ForeignKey(
        ProductSizeRange, on_delete=models.SET_NULL, null=True, blank=True, related_name='products_min_size'
    )
    max_size = models.ForeignKey(
        ProductSizeRange, on_delete=models.SET_NULL, null=True, blank=True, related_name='products_max_size'
    )
    fit = models.ForeignKey(
        ProductFit, on_delete=models.SET_NULL, null=True, blank=True, related_name='products'
    )
    gender = models.IntegerField(choices=GENDER_CHOICES, default=1)
    gsm = models.CharField(max_length=50, null=True, blank=True)

    product_code = models.CharField(max_length=100)
    product_name = models.CharField(max_length=255)
    is_highlighted = models.BooleanField(default=False)
    is_featured = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    specifications = models.TextField(null=True, blank=True)
    product_image = models.CharField(max_length=255, null=True, blank=True)
    product_image_alttext = models.CharField(max_length=255, null=True, blank=True)
    product_images = models.JSONField(null=True, blank=True)


    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.product_name

    


class ProductDetails(models.Model):
    id = models.BigAutoField(primary_key=True)
    product = models.ForeignKey(Products, on_delete=models.CASCADE, related_name='additional_details')
    product_details = models.TextField(null=True, blank=True)
    printing_options = models.TextField(null=True, blank=True)
    textile_care = models.TextField(null=True, blank=True)
    packaging = models.CharField(max_length=255, null=True, blank=True)
    counterparts = models.CharField(max_length=255, null=True, blank=True)
    sizeSpecificationImage = models.CharField(max_length=255, null=True, blank=True)
    certificate_images = models.JSONField(null=True, blank=True)  # <-- add this line
    def __str__(self):
        return f"Additional Details for {self.product.product_name}"

class ProductMeta(models.Model):
    id = models.BigAutoField(primary_key=True)
    product = models.ForeignKey(Products, on_delete=models.CASCADE, related_name='meta')
    meta_title = models.TextField(null=True, blank=True)
    meta_description = models.TextField(null=True, blank=True)
    meta_keywords = models.TextField(null=True, blank=True)
    meta_robots_index = models.CharField(max_length=10, choices=[('index', 'index'), ('noindex', 'noindex')], default='index')
    meta_robots_follow = models.CharField( max_length=10, choices=[('follow', 'follow'), ('nofollow', 'nofollow')], default='follow')
    meta_canonical = models.TextField(null=True, blank=True)
    meta_image = models.CharField(max_length=255, null=True, blank=True)  # new: OG/Twitter image

    # Open Graph fields
    og_title = models.CharField(max_length=255, null=True, blank=True)
    og_description = models.TextField(null=True, blank=True)
    og_url = models.CharField(max_length=255, null=True, blank=True)
    og_type = models.CharField(
        max_length=50, choices=[('product', 'Product')], default='product', null=True, blank=True
    )

    # Twitter Card fields
    TWITTER_CARD_CHOICES = [
        ('summary', 'Small Preview'),
        ('summary_large_image', 'Large Preview (default)'),
    ]
    twitter_card = models.CharField(
        max_length=50, choices=TWITTER_CARD_CHOICES, default='summary_large_image', null=True, blank=True
    )
    twitter_title = models.CharField(max_length=255, null=True, blank=True)
    twitter_description = models.TextField(null=True, blank=True)

    meta_social = models.JSONField(null=True, blank=True)  # for any extra social meta

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Meta for {self.product.product_name}"






