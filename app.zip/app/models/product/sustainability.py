from django.db import models

class ProductSustainability(models.Model):
    STATUS_CHOICES = (
        ('1', 'Active'),
        ('0', 'Inactive'),
    )
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=1, choices=STATUS_CHOICES, default='1')

    def __str__(self):
        return self.name
