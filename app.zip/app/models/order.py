from django.db import models
from app.models.user.common import Users
from app.models.product.products import Products

class PaymentMethods(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.name




class Orders(models.Model):
    id = models.BigAutoField(primary_key=True)
    user_id = models.ForeignKey(Users,on_delete=models.CASCADE,related_name='orders',db_column='user_id')
    product_id = models.ForeignKey(Products,on_delete=models.CASCADE,related_name='orders',db_column='product_id')
    quantity = models.PositiveIntegerField(default=1)
    order_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, default='pending')  # e.g., pending, completed, cancelled
    order_json = models.JSONField(null=True, blank=True)  # For storing additional order details
    def __str__(self):
        return f"Order {self.id} by {self.user.full_name} for {self.product_id}"