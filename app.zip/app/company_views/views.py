from django.shortcuts import render, redirect
from app.models.user.common import Users

def company_dashboard(request):
    user_id = request.session.get('user_id')
    user_type = request.session.get('user_type')
    if not user_id or user_type != 3:
        return redirect('/signin/')
    user = Users.objects.get(id=user_id)
    return render(request, 'company/index.html', {'user': user})