from django.urls import path, include
from app.views import forgotpassword_api, forgotpassword_otp_api, forgotpassword_reset_api, signin_api, signup_api, getcountry

urlpatterns = [
    #path('', include('app.admin_views.urls', namespace='main_admin')),
    path('app/signin', signin_api, name='signin_api'),
    path('app/signup', signup_api, name='signup_api'),
    path('api/forgotpassword', forgotpassword_api, name='forgotpassword_api'),
    path('api/forgotpassword/otp', forgotpassword_otp_api, name='forgotpassword_otp_api'),
    path('api/forgotpassword/reset', forgotpassword_reset_api, name='forgotpassword_reset_api'),
    path('api/getcountry', getcountry, name='getcountry'),
]